package com.cg.exception;

public class AccountException extends Exception{

	public AccountException(Object object) {
		// TODO Auto-generated constructor stub
	}

}
