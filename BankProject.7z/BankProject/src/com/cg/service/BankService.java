package com.cg.service;

import java.sql.SQLException;
import com.cg.entity.Account;
import com.cg.exception.AccountException;

public interface BankService {
	
	public int createaccount(Integer a,Account b) throws ClassNotFoundException, SQLException;
	
	public Account getbalance(int a) throws ClassNotFoundException, SQLException;
	
	public Account deposit(int accno,double bal) throws SQLException, ClassNotFoundException;
	
	public Account withdraw(int accno,double bal) throws ClassNotFoundException, SQLException;
	
	public boolean validateCusName(String name) throws AccountException;
		
		
		
		public boolean validateMobileNo(String cellno) throws AccountException ;
	

}
