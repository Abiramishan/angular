package com.cg.pp.junit;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.cg.pp.dao.AccountDAO;
import com.cg.pp.dao.AccountDAOIMPl;
import com.cg.pp.entity.Account;
import com.cg.pp.entity.Customer;
import com.cg.pp.exception.InvalidDataException;

public class AccountTestCase {

	/*@Test
	public void test() {
		fail("Not yet implemented");
	}*/
	static  AccountDAO adao=new AccountDAOIMPl();
	@Test
	public void createaccount() throws InvalidDataException{
	Assert.assertEquals("945958742365",adao.createAccount(new Customer("Sarah","9490150279",25,"Sarah02@gmail.com","432504659687","Eluru",630002), new Account("945958742365", 63000.0 )));
}
	

	@Test
	public void showbalance() {
		double ac=adao.showBalance("945958742365");
		Assert.assertEquals(Double.doubleToLongBits(ac), Double.doubleToLongBits(63000.0));
		
	} 

	@Test
	public void deposit() {
		double acc=adao.deposit("945958742365", 10000.0);
		Assert.assertEquals(Double.doubleToLongBits(73000.0), Double.doubleToLongBits(acc));
	}
	
	@Test
	public void withdraw() {
		double acc=adao.withDraw("945958742365", 1000.0);
		Assert.assertEquals(Double.doubleToLongBits(62000.0), Double.doubleToLongBits(acc));
		
	}
}
