package com.cg.pp.dao;
	import com.cg.pp.entity.Account;
	import com.cg.pp.entity.Customer;
	import com.cg.pp.util.CollectionUtil;

	public class AccountDAOIMPl implements AccountDAO{

		@Override
		public String createAccount(Customer c, Account acc) {
			CollectionUtil.createAccount(c, acc);
			return acc.getAccNumber();
		}

		@Override
		public double showBalance(String accNo) {
			
			return CollectionUtil.showBalance(accNo);
		}

		@Override
		public double deposit( String accNo,double amount) {
			
			return CollectionUtil.deposit(accNo, amount);
		}

		@Override
		public double withDraw( String accNo,double amount) {
			 
			return CollectionUtil.withDraw(accNo, amount);
		}

		@Override
		public double fundTransfer(String accNo, double amount) {
			
			return CollectionUtil.fundTransfer(accNo,amount);
		}

		@Override
		public Account printTransactions(String accNo) {
			
			return CollectionUtil.printTransactions(accNo);
		}

	}


