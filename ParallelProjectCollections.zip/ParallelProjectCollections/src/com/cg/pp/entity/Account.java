package com.cg.pp.entity;

public class Account {
		private final  String bankName = "XYZ Bank";
		private final String branch = "Polavaram";
		private final String ifscCode = "XYZB000229";
		private String accNumber ;
	    private double accbalance;
		public Account()
		{
			super();
		}
		public Account(String accNumber, double accbalance) {
			super();
			this.accNumber = accNumber;
			this.accbalance = accbalance;
		}
		public String getAccNumber() {
			return accNumber;
		}
		public void setAccNumber(String accNumber) {
			this.accNumber = accNumber;
		}
		public double getAccbalance() {
			return accbalance;
		}
		public void setAccbalance(double accbalance) {
			this.accbalance = accbalance;
		}
		public String getBankName() {
			return bankName;
		}
		public String getBranch() {
			return branch;
		}
		public String getIfscCode() {
			return ifscCode;
		}
		@Override
		public String toString() {
			return "Account [bankName=" + bankName + ", branch=" + branch + ", ifscCode=" + ifscCode + ", accNumber="
					+ accNumber + ", accbalance=" + accbalance + "]";
		}
	}


