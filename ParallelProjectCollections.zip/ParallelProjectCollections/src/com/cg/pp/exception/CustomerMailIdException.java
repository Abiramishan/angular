
package com.cg.pp.exception;

public class CustomerMailIdException  extends Exception{

	
	private static final long serialVersionUID = 1L;

	public CustomerMailIdException(String mailId) {
		super(mailId);
		System.out.println("Mail id should have @ symbol.");
	}

	
}
