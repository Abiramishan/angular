package com.cg.pp.exception;

public class InvalidDataException extends Exception {

}
