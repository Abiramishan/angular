package com.cg.pp.exception;

public class CustomerAgeException extends Exception{

	private static final long serialVersionUID = 1L;

	public CustomerAgeException(String age) {
		super(age);
		System.out.println("Not Sufficient Age");
	}

	
}
