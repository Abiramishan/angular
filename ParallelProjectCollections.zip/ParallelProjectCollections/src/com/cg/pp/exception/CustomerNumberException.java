package com.cg.pp.exception;

public class CustomerNumberException extends Exception{

	private static final long serialVersionUID = 1L;

	public CustomerNumberException(String number) {
		super(number);
		System.out.println("Number Should be 10 digits");
	}

	
	
}
