package com.cg.pp.exception;

public class BalanceException extends Exception {

	private static final long serialVersionUID = 1L;

	public BalanceException(String balance) {
		super(balance);
		System.out.println("No Sufficient Balance");
	}
	
	

}

