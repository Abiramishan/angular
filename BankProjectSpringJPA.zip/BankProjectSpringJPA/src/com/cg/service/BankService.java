package com.cg.service;

import com.cg.entity.Account;

public interface BankService {

	public Account addAccount(Account bank);
	public Account showBalance(int accountNo);
	public Account deposit(int accountNo, int amount);
	public Account withdraw(int accountNo, int amount);
	public Account fundTransfer(int accountNo, int accountNo2, int amount);
	

}
