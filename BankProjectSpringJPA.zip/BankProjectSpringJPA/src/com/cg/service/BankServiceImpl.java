package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.BankDAO;
import com.cg.entity.Account;

@Service
@Transactional
public class BankServiceImpl implements BankService {


	@Autowired
	BankDAO bankdao;
	@Override
	public Account addAccount(Account bank) {
		
		return bankdao.addAccount(bank);
	}

	@Override
	public Account showBalance(int accountNo) {
		
		return bankdao.showBalance(accountNo);
	}

	@Override
	public Account deposit(int accountNo, int amount) {
		
		return bankdao.deposit(accountNo, amount);
	}

	@Override
	public Account withdraw(int accountNo, int amount) {
		
		return bankdao.withdraw(accountNo, amount);
	}

	@Override
	public Account fundTransfer(int accountNo, int accountNo2, int amount) {
		
		return bankdao.fundTransfer(accountNo, accountNo2, amount);
	}


}
