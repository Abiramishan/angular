package com.cg.dao;

import com.cg.entity.Account;

public interface BankDAO {

	public Account addAccount(Account bank);
	public Account showBalance(int accountNo);
	public Account deposit(int accountNo, int amount);
	public Account withdraw(int accountNo, int amount);
	public Account fundTransfer(int accountNo, int accountNo2, int amount);

}
