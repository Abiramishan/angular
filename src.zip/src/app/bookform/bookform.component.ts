import { Component, OnInit } from '@angular/core';
import { FormGroup , FormControl,Validator, Validators} from '../../../node_modules/@angular/forms';
import { IBook } from '../book/book';
import { BookService } from '../book.service';

@Component({
  selector: 'app-bookform',
  templateUrl: './bookform.component.html',
  styleUrls: ['./bookform.component.css']
})
export class BookformComponent implements OnInit {

  userForm : FormGroup;
  books:IBook[];
  constructor(private service : BookService) { }

  ngOnInit() {
    this.userForm =new FormGroup({
      //userForm : FormGroup = new FormGroup({
        id : new FormControl(),
        title : new FormControl('Angular',[Validators.required,Validators.minLength(6)] ),
        year : new FormControl(null,[Validators.required,Validators.pattern("^[0-9]{4}$")]),
        author : new FormControl()
      });
    this.service.getBook().subscribe(data=>this.books=data);
  }
onSubmit(obj :any)
{
  this.books.map(p=> p.title).forEach(p=>console.log(p));
  let arr=this.books.filter(p=>p.id==obj.id);
  if(arr.length>0)
  {
    alert('Id already exist ')
  }
  else{
  this.books.push({id :obj.id , title:obj.title, year:obj.year, author : obj.author });
  }
//console.log(obj);
}
}
