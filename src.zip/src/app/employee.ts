export interface IEmployee
{
    empid:number;
    empname:string;
    salary:number;
}