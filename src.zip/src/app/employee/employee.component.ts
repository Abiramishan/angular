import { Component, OnInit } from '@angular/core';
import { IEmployee } from '../employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  
  employees :IEmployee []=[{
    empid:111,
    empname:'abirami',
    salary:20000},
    {
      empid:113,empname:'priya',salary:40000
    }
  ];
  constructor() { }

  ngOnInit() {
  }
  delete(emp : IEmployee)
  {
    let arr=this.employees.filter(p=>p.empid != emp.empid);
    this.employees=arr;
  }
}
