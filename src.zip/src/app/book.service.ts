import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { IBook } from './book/book';
@Injectable({
  providedIn: 'root'
})
export class BookService {

  url : string = "assets/booklist.json";
  constructor( private http: HttpClient) { }
  getBook():Observable<IBook []>
  {
    return this.http.get<IBook []>(this.url);
  }
}
