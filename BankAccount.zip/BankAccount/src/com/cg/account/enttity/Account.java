package com.cg.account.enttity;

public class Account {
	int accountNumber;
	String accountType;
	String branch;
	String ifsc;
	int balance;
	
	public Account(int accountNumber, String accountType, String branch,
			String ifsc, int balance) {
		super();
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.branch = branch;
		this.ifsc = ifsc;
		this.balance = balance;
	}	
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", accountType="
				+ accountType + ", branch=" + branch + ", ifsc=" + ifsc
				+ ", balance=" + balance + "]";
	}
	

}
