package com.cg.account.service;

import java.util.HashMap;

import com.cg.account.enttity.Account;
import com.cg.account.enttity.Customer;
import com.cg.account.exception.AccountException;

public interface AccountService {
	abstract HashMap<Integer, Account> showBalance(int accid);

	abstract HashMap<Integer, Customer> validateMob(String mobno);

	abstract int addCustomer(int cusid, Account account);

	boolean validateCustomerMobileNo(String customerMobileNo) throws AccountException;

	boolean validateCustomerName(String cusname) throws AccountException;

	boolean validateAcctype(String acctype) throws AccountException;

	boolean validateCustomerAddress(String customerAddress) throws AccountException;

}
