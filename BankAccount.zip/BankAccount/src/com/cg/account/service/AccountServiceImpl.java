package com.cg.account.service;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.account.dao.AccountDAO;
import com.cg.account.dao.AccountDAOImpl;
import com.cg.account.enttity.Account;
import com.cg.account.enttity.Customer;
import com.cg.account.exception.AccountException;

public class AccountServiceImpl implements AccountService {

	
		AccountDAO cusdao = new AccountDAOImpl();
		@Override
		public boolean validateCustomerName(String cusname) throws AccountException {
			Pattern pattern = Pattern.compile("^[A-Z]{1}[a-z]{3,10}");
			Matcher cusnameMatch = pattern.matcher(cusname);
			if (cusnameMatch.matches())
			{
				return true;
			}
			return false;
		}
		@Override
		public boolean validateCustomerMobileNo(String customerMobileNo) throws AccountException {
			Pattern pattern = Pattern.compile("^[0-9]{10}");
			Matcher customerMobileNoMatch = pattern.matcher(customerMobileNo);
			if (customerMobileNoMatch.matches())
			{
				return true;
			}
			return false;
		}
			
		/*@Override
		public boolean validateCustomerMobileNo(String customerMobileNo) throws CustomerException
		{
			Pattern pattern = Pattern.compile("^[0-9] {10}");
			Matcher customerMobileNoMatch = pattern.matcher(customerMobileNo);
			if (customerMobileNoMatch.matches())
			{
				return true;
			}
				return false;
		}*/
		
		@Override
		public boolean validateCustomerAddress(String customerAddress) throws AccountException {
			Pattern pattern = Pattern.compile("^[A-Z]{1}[a-z]{3,20}");
			Matcher customerAddressMatch = pattern.matcher(customerAddress);
			if (customerAddressMatch.matches())
			{
				return true;
			}
			return false;
		}
		@Override
		public boolean validateAcctype(String acctype) throws AccountException 
		{	
			String a1="Savings";
			String a2="Current";
			if (acctype.equals(a1) || acctype.equals(a2))
			{
				return true;
			}
			return false;
		}
		
		public HashMap<Integer, Account> showBalance(int accid) {
			 HashMap<Integer, Account> w= cusdao.showBalance(accid);
			return w;
		}

		public HashMap<Integer, Customer> validateMob(String mobno) {
			HashMap<Integer, Customer>hm= cusdao.validateMob(mobno);
			return hm;
		}

		public int addCustomer(int cusid, Account account) {
			cusdao.addCustomer( cusid, account);
			return 0;
		}

}
