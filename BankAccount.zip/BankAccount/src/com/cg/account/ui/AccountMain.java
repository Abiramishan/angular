package com.cg.account.ui;

import java.util.HashMap;
import java.util.Scanner;

import com.cg.account.enttity.Account;
import com.cg.account.enttity.Customer;
import com.cg.account.exception.AccountException;
import com.cg.account.service.AccountService;
import com.cg.account.service.AccountServiceImpl;

public class AccountMain {
	
		static Scanner scanner ;
		static Customer customer;
		static AccountService cusser;
		
		static int min=1554,max=1659;
		static int cusid = ((int) (Math.random()*(( max-min)+1))+min);
		
		public static void main(String[] args)
		{
			while(true)
			{
			scanner = new Scanner(System.in);
			customer = new Customer ();
			cusser = new AccountServiceImpl();
			
		System.out.println("Welcome to Yeskee Bank...Choose the below option as per your need");
		System.out.println("1.To Create account");
		System.out.println("2.Show Balance");
		System.out.println("3.To Deposit Money");
		System.out.println("4.To Withdraw Money");
		System.out.println("5.To Transfer Money");
		System.out.println("6.To Print Recent Transactions");
		int choice = 0;
		choice = scanner.nextInt();
		switch (choice)
		{
		case 1:
			addCustomer();
			break;
		case 2:
			showBalance();
			break;
		case 3:
			deposit();
			break;
		case 4:
			withDraw();
			break;
		case 5:
			fundTransfer();
			break;
		case 6:
			printrecenttransactions();
			break;
		case 7:
			break;
		}	
			}
		}
		private static void addCustomer() 
		{
			System.out.println("Enter your name");		
			String cusname= scanner.next();
			
			try
			{			
				if (cusser.validateCustomerName(cusname))
				{
					while(true)
					{
						System.out.println("Enter Mobile Number");
						String customerMobileNo= scanner.next();
						
						if (cusser.validateCustomerMobileNo(customerMobileNo))
						{
							while (true)
							{
								System.out.println("Enter Your Address");
								String customerAddress=scanner.next();
								
								if(cusser.validateCustomerAddress(customerAddress))
								{
								while (true)
								{			
									System.out.println("Enter type of account you wanna open (Savings/Current)");
									String acctype=scanner.next();
									if(cusser.validateAcctype(acctype))
									{
									while (true)
									{
									System.out.println("Enter Initial amount to deposit in your account");
									int balance=scanner.nextInt();
									String branch = "Palani";
									String ifsc = "YESC1125";						
									Account account= new Account(cusid,acctype, branch, ifsc,balance);							
									cusser.addCustomer(cusid, account);
									System.out.println();
									System.out.println("Congrats!!!...Account created successfully.. please take a note of your Customer Id " +cusid);
									System.out.println();
									System.out.println("Your Account Details");
									System.out.println();
									System.out.println("Customer Id:" +cusid);
									System.out.println("Account Type:" +acctype);
									System.out.println("Account Balance:" +balance);
									System.out.println("IFSC:" +ifsc);
									System.out.println("Branch:" +branch);
									dummy();
									break;
									}
									}
									else
									{
										System.out.println("Enter Savings/Current in correct way");
									}
									break;
								}				
								}
							break;
							}
						}
					break;
					}
				}
			} 
			catch (AccountException e)
			{	
				
			}	
		}
		private static void dummy()
		{
			for(int i=0; i<2;i++)
			{		
				while (true)
				{
				addcuscallmethod();
				break;
				}
			}		
		}

		private static void addcuscallmethod()
		{
			System.out.println();
			System.out.println("1.To Deposit Money");
			System.out.println("2.To Withdraw Money");
			System.out.println("3.To Transfer Money");
			System.out.println("4.Show Account Balance");
			System.out.println("5.Exit");
			int choice = 0;
			choice = scanner.nextInt();
			switch (choice)
			{
			case 1:
				deposit();
				break;
			case 2:
				withDraw();
				break;
			case 3:
				fundTransfer();
				break;
			case 4:
				showBalance();
				break;
			case 5:
				System.out.println("Thanks for using our Bank Application");
				break;
			default:
				System.out.println("Invalid Input");
			}
		}
		
		@SuppressWarnings("unused")
		private static void mobileVerification()
		{
			System.out.println("Enter your Mobile Number");
			String mobno = scanner.next();
	     	 HashMap<Integer, Customer> hm=cusser.validateMob(mobno);
		   	HashMap<Integer, Customer> w = new  HashMap<Integer, Customer>(hm);
		   	for (Integer g : w.keySet())
			 {
		   		Customer k = w.get(g);
		   		System.out.println("Saajkbk");
		   		System.out.println(k.getCustomerMobileNo());
			 }
		}	
		private static void showBalance()
		{
		   	System.out.println("Enter your Account Id");
		   	int accid = scanner.nextInt();
			 HashMap<Integer, Account> am=cusser.showBalance(accid);
			 HashMap<Integer, Account> s = new  HashMap<Integer, Account>(am);
			 for (Integer b : s.keySet())
			 {
				 Account d = s.get(b);
				 int accno= d.getAccountNumber();
				 if (accid==accno)
				 {			 
					 System.out.println("Account Balance in the account Id "+accid +" is "  +d.getBalance());
				 }
				 else
				 continue;
			 }
		}	
		private static void deposit()
		{
			 System.out.println("Enter your Account Id");
		     int accid = scanner.nextInt();
			 HashMap<Integer, Account> am=cusser.showBalance(accid);
			 HashMap<Integer, Account> s = new  HashMap<Integer, Account>(am);
			 for (Integer b : s.keySet())
			 {
				 Account d = s.get(b);
				 int accno= d.getAccountNumber();
				 if (accid==accno)
				 {			
					 int bal =d.getBalance();
					 System.out.println("Balance in the Account "+accid +" before deposit: "+bal );
					 System.out.println("Enter amount to deposit");
					 int amount = scanner.nextInt();
					 bal = amount+bal;
					 Account account= new Account(d.getAccountNumber(), d.getAccountType(),d.getBranch(),d.getIfsc(),bal);							
				     cusser.addCustomer(d.getAccountNumber(), account);
					 
					 System.out.println("Successfully Deposited Rs "+amount +" Your Account Balance After Deposit is: "+bal);			
				 }
				 else
				 continue;
			 }
		}
		private static void withDraw()
		{
			System.out.println("Enter your Account Id");
		   	int accid = scanner.nextInt();
			 HashMap<Integer, Account> am=cusser.showBalance(accid);
			 HashMap<Integer, Account> s = new  HashMap<Integer, Account>(am);
			 for (Integer b : s.keySet())
			 {
				 Account d = s.get(b);
				 int accno= d.getAccountNumber();
				 if (accid==accno)
				 {			
					 int bal =d.getBalance();
					 System.out.println("Balance in the Account "+accid +" before withdraw: "+bal );
					 System.out.println("Enter amount to withdraw");
					 int amount = scanner.nextInt();
					 if(amount<bal)
					 {
						 bal = bal-amount;
						 System.out.println("Successfully Withdrawed "+amount +" Your Account Balance After Withdraw is: "+bal);	
					 }
					 else
					 {
						 System.out.println("Your account is not having the amount you entered");
					 }
				 }
				 else
				 continue;
			 }	
		}
		private static void fundTransfer()
		{
			System.out.println("Enter your Account Id");
		   	int accid = scanner.nextInt();
			 HashMap<Integer, Account> am=cusser.showBalance(accid);
			 HashMap<Integer, Account> s = new  HashMap<Integer, Account>(am);
			 for (Integer b : s.keySet())
			 {
				 Account d = s.get(b);
				 int accno= d.getAccountNumber();
				 if (accid==accno)
				 {				
					 int bal =d.getBalance();
					 System.out.println("Balance in the Account "+accid +" before transfer: "+bal );
					 System.out.println("Enter amount to transfer");
					 int amount = scanner.nextInt();
					 if(amount<bal)
					 {
						 	bal = bal-amount;
						 	
						 	System.out.println("Enter Account Id to transfer");
							int accid1 = scanner.nextInt();
							 HashMap<Integer, Account> am1=cusser.showBalance(accid1);
							 HashMap<Integer, Account> s1 = new  HashMap<Integer, Account>(am1);
							for (Integer b1 : s1.keySet())
							 {
								 Account d1 = s1.get(b1);
								 int accno1= d1.getAccountNumber();
								 if (accid1==accno1)
								 {			
									 int bal1 =d1.getBalance();
									 System.out.println("Transfer Successful");
									 System.out.println("Balance in the Account "+accid1 +" before transfer: "+bal1 );
									 bal1 = amount+bal1;
									 System.out.println("Balance in the Account "+accid1 +" after transfer: "+bal1 );
									 System.out.println("Balance in the Account "+accid +" after transfer : "+bal );
								 }
								 else
								 continue;
								 break;
							 } 
					 }
					 else
					 {
						 System.out.println("Your account is not having the amount you entered");
					 }
				 }
				 else
				 continue;
			 }
		}
		private static void printrecenttransactions() 
		{	
			
				
			 System.out.println("Enter your Account Id to deposit");
		     int accid = scanner.nextInt();
			 HashMap<Integer, Account> am=cusser.showBalance(accid);
			 HashMap<Integer, Account> s = new  HashMap<Integer, Account>(am);
			 for (Integer b : s.keySet())
			 {
				 Account d = s.get(b);
				 int accno= d.getAccountNumber();
				 if (accid==accno)
				 {			
					 int bal =d.getBalance();
					 System.out.println("Balance in the Account "+accid +" before deposit: "+bal );
					 System.out.println("Enter amount to deposit");
					 int amount = scanner.nextInt();
					 bal = amount+bal;
					 Account account= new Account(d.getAccountNumber(), d.getAccountType(),d.getBranch(),d.getIfsc(),bal);							
				     cusser.addCustomer(d.getAccountNumber(), account);
					 
					 //System.out.println("Successfully Deposited Rs "+amount +" Your Account Balance After Deposit is: "+bal);			
				 }
				 else
				 continue;
			 }
			 
			 
			 System.out.println("Enter your Account Id to withdraw");
			   	int accid1 = scanner.nextInt();
				 HashMap<Integer, Account> am1=cusser.showBalance(accid1);
				 HashMap<Integer, Account> s1 = new  HashMap<Integer, Account>(am1);
				 for (Integer b : s1.keySet())
				 {
					 Account d = s1.get(b);
					 int accno= d.getAccountNumber();
					 if (accid1==accno)
					 {			
						 int bal =d.getBalance();
						 System.out.println("Balance in the Account "+accid1 +" before withdraw: "+bal );
						 System.out.println("Enter amount to withdraw");
						 int amount1 = scanner.nextInt();
						 if(amount1<bal)
						 {
							 int bal2 = bal-amount1;
							 System.out.println("Recent transactions are");
							 System.out.println("1.Deposit of rupees "+amount1 +"has done and the updated balance is " + bal );
							 System.out.println("1.Deposit of rupees "+amount1 +"has done and the updated balance is " + bal2 );
							 //System.out.println("Successfully Withdrawed "+amount +" Your Account Balance After Withdraw is: "+bal);	
						 }
						 else
						 {
							 System.out.println("Your account is not having the amount you entered");
						 }
					 }
					 else
					 continue;
				 }	
			
			/* 
			dummy();
			System.out.println("Recent Transactions are shown above\t");
			System.out.println();
			*/
			
		}

}
