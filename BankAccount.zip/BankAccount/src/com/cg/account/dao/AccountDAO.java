package com.cg.account.dao;

import java.util.HashMap;

import com.cg.account.enttity.Account;
import com.cg.account.enttity.Customer;

public interface AccountDAO {

	abstract HashMap<Integer, Account> showBalance(int accid);

	abstract HashMap<Integer, Customer> validateMob(String mobno);

	abstract void addCustomer(int cusid, Account account);
}
