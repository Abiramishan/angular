package com.cg.account.dao;

import java.util.HashMap;

import com.cg.account.enttity.Account;
import com.cg.account.enttity.Customer;
import com.cg.account.util.Collectionsutil;

public class AccountDAOImpl implements AccountDAO{
Collectionsutil cu = new Collectionsutil();
	
	@Override
	public HashMap<Integer, Account> showBalance(int accid) {
		 HashMap<Integer, Account> w =cu.showBalance(accid);
		return w;
	}

	@Override
	public HashMap<Integer, Customer> validateMob(String mobno) {
		 HashMap<Integer, Customer>hm =cu.validateMob(mobno);
		return hm;
	}

	@Override
	public void addCustomer(int cusid, Account account) {
		cu.addCustomer (cusid, account);
		
	}


}
