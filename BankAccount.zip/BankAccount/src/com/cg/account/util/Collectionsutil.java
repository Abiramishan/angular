package com.cg.account.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.account.enttity.Account;
import com.cg.account.enttity.Customer;

public class Collectionsutil {
public static HashMap<Integer, Customer> hm = new HashMap<>();
	
	static 
	{
		hm.put(1654, new Customer(1654,"Satheesh","9865986598","palani"));
		hm.put(1655, new Customer(1655,"tharun","8760815735","erode"));
		hm.put(1656, new Customer(1656,"saravana","9876549876","madurai"));
		hm.put(1657, new Customer(1657,"sangeeth","7894567894","salem"));
		hm.put(1658, new Customer(1658,"Yashwanth","9511595159","chennai"));
	}
	
	public static HashMap<Integer, Account> am = new HashMap<>();
	
	static
	{
		am.put(1654, new Account (1654,"Savings","Cbe","YESC1125",12000));
		am.put(1655, new Account (1655,"Current","Cbe","YESC1125",16000));
		am.put(1656, new Account (1656,"Current","Cbe","YESC1125",10000));
		am.put(1657, new Account (1657,"Savings","Cbe","YESC1125",52000));
		am.put(1658, new Account (1658,"Savings","Cbe","YESC1125",32000));
	}

	public HashMap<Integer, Account> showBalance(int accid)
	{
		if (am.containsKey(accid))
		{
			
		return am;
		}
		else
		{
			System.out.println("No such Account");
		}
		return null;		
	}

	public HashMap<Integer, Customer> validateMob(String mobno) {

		if(hm.containsValue(mobno))
				{
			System.out.println("got it");
			return hm;
				}
			return hm;
	}

	public void addCustomer(int cusid, Account account) {
		am.put(cusid, account);
		
	}


	
}
