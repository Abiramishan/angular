package com.cg.account.exception;

public class AccountException extends Exception {

}
