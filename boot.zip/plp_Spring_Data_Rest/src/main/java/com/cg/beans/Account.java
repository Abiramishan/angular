package com.cg.beans;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
/***
 * 
 * @author banuprr
 *
 */
@Entity
@Table(name = "Wallet_Account_spring_data")
@Component
public class Account implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "myseq")
	@SequenceGenerator(name = "myseq",sequenceName = "accountsequencespringdata",initialValue =7980,allocationSize = 1)
	private int accountNo;
	private double balance;
	
	public Account() {
		super();
	}
	public Account(int accountNo, double balance) {
		super();
		this.accountNo = accountNo;
		this.balance = balance;
	}
	
	public Account(double balance) {
		super();
		this.balance = balance;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "accountNo=" + accountNo + ", balance=" + balance ;
	}
	
}
