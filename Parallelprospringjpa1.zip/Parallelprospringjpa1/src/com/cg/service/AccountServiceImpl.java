package com.cg.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.AccountDao;
import com.cg.entity.Account;

@Service
@Transactional
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountDao aDao;
	
	@Override
	public Account createAccount( Account acc) {
		return aDao.createAccount( acc);
	}

	@Override
	public Account showBalance(int accNo) {
		return aDao.showBalance(accNo);
	}

	@Override
	public Account deposit(int accNo, double amount) {
		return aDao.deposit(accNo, amount);
	}

	@Override
	public Account withDraw(int accNo, double amount) {
		return aDao.withDraw(accNo, amount);
	}

	@Override
	public Account fundTransfer(int accNo, double amount) {
		return aDao.fundTransfer(accNo, amount);
	}

	@Override
	public Account printTransactions(int accNo) {
		return aDao.printTransactions(accNo);
	}

}
