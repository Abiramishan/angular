package com.cg.entity;
	import java.io.Serializable;

	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.Table;

	@Entity
	@Table(name="AccountSpringJPA")
	public class Account implements Serializable{
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private int accountNum;
		
		private double balance;
		private String cusName;
		
		private String address;
		public int getAccountNum() {
			return accountNum;
		}
		public void setAccountNum(int accountNum) {
			this.accountNum = accountNum;
		}
		
		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance) {
			this.balance = balance;
		}
		public String getCusName() {
			return cusName;
		}
		public void setCusName(String cusName) {
			this.cusName = cusName;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public Account(int accountNum, int pin, int balance, String cusName, String address) {
			super();
			this.accountNum = accountNum;
			
			this.balance = balance;
			this.cusName = cusName;
			this.address = address;
		}
		public Account() {
			super();
			
		}
		@Override
		public String toString() {
			return "Bank [accountNum=" + accountNum + ", balance=" + balance + ", cusName=" + cusName
					+ ", address=" + address + "]";
		}
}
