package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.entity.Account;
import com.cg.service.AccountService;

@Controller
public class AccountController {

	@Autowired
	AccountService accountService;
	Account account=new Account();
	@RequestMapping("/index")
	public String showForm(Model model) {
		model.addAttribute("account",account);
		return "index";
		
	}
	@RequestMapping("/addaccount")
	public String add(Model model) {
		Account account=new Account();
		model.addAttribute("account", account);
	
		return "addaccount";
	}

	@RequestMapping(value="/addAccount", method=RequestMethod.GET)
	public String addTrainee(@ModelAttribute("account") Account account,Model model) {
		Account acc=accountService.createAccount(account);
		model.addAttribute("account", account);
		return "Success";
	}
	@RequestMapping("/showbalance")
	public String show(Model model) {
		Account account=new Account();
		model.addAttribute("account", account);
		return "showbalance";
	}

	@RequestMapping(value="/showbalancecheck", method=RequestMethod.GET)
	public String showbalance(@ModelAttribute("account") Account account,Model model) {
		model.addAttribute("account", accountService.showBalance(account.getAccountNum()));
		return "showbalanceSuccess";
	}
	
	@RequestMapping("/deposit")
	public String deposit(Model model) {
		model.addAttribute("account", account);
	
		return "deposit";
	}

	@RequestMapping(value="/depositcheck", method=RequestMethod.GET)
	public String depositAmt(@ModelAttribute("account") Account account,Model model) {
		model.addAttribute("account", accountService.deposit(account.getAccountNum(), account.getBalance()));
		return "depositSuccess";
	}
	
	@RequestMapping("/withdraw")
	public String withDraw(Model model) {
		
		model.addAttribute("account", account);
	
		return "withdraw";
	}

	@RequestMapping(value="/withdrawcheck", method=RequestMethod.GET)
	public String withDrawAmt(@ModelAttribute("account") Account account,Model model) {
		
		model.addAttribute("account", accountService.withDraw(account.getAccountNum(), account.getBalance()));
		return "withdrawSuccess";
	}
	
	@RequestMapping("/fundtransfer")
	public String fundtrans(Model model) {
		model.addAttribute("account", account);
		return "fundtransfer";
	}

	@RequestMapping(value="/transfer", method=RequestMethod.GET)
	public String fundtransfer(@ModelAttribute("account") Account account,Model model) {
		
		model.addAttribute("account", accountService.fundTransfer(account.getAccountNum(), account.getBalance()));
		return "fundtransferSuccess";
	}
	@RequestMapping("/printtransactions")
	public String print(Model model) {
		model.addAttribute("account", account);
		return "printtransactions";
	}

	@RequestMapping(value="/print", method=RequestMethod.GET)
	public String printtransaction(@ModelAttribute("account") Account account,Model model) {
		
		model.addAttribute("account", accountService.printTransactions(account.getAccountNum()));
		return "printSuccess";
	}
}
