package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entity.Account;

@Repository
public class AccountDaoImpl implements AccountDao {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public  Account createAccount(Account acc) {
		entityManager.persist(acc);
		
		entityManager.flush();
		return acc;
	}

	@Override
	public Account showBalance(int accNo) {
		Account  acc= entityManager.find(Account.class, accNo);
		if(acc!=null)
		{
			
		return acc;
		}
		else {
			
			return null;
		}	
		
	}

	@Override
	public Account deposit(int accNo, double amount) {
		
		Account  acc= entityManager.find(Account.class, accNo);
		String str="SELECT acc.balance FROM Account acc WHERE acc.accountNum=:num";
		TypedQuery<Double> query=entityManager.createQuery(str,Double.class);
		query.setParameter("num",accNo);
		Double dou=query.getSingleResult();
		Double balance = dou+amount;
		acc.setBalance(balance);
        return acc;
	}

	@Override
	public Account withDraw(int accNo, double amount) {
	
		Account  acc= entityManager.find(Account.class, accNo);
		String str="SELECT acc.balance FROM Account acc WHERE acc.accountNum=:num";
		TypedQuery<Double> query=entityManager.createQuery(str,Double.class);
		query.setParameter("num",accNo);
		Double dou=query.getSingleResult();
		double balance = dou-amount;
		acc.setBalance(balance);
	
		return acc;
	}

	@Override
	public Account fundTransfer(int accNo, double amount) {
		 
		  Account  acc= entityManager.find(Account.class, accNo);
		  String str="SELECT acc.balance FROM Account acc WHERE acc.accountNum=:num";
		  TypedQuery<Double> query=entityManager.createQuery(str,Double.class);
		  query.setParameter("num",accNo);
		  Double dou=query.getSingleResult();
		  double balance = dou-amount;
			acc.setBalance(balance);
		
         return acc;
	}

	@Override
	public Account printTransactions(int accNo) {
			  Account  acc= entityManager.find(Account.class, accNo);
		      return acc;
	}


}
