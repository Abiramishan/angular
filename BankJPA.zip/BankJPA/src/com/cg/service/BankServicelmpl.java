package com.cg.service;

import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.cg.dao.BankDAO;
import com.cg.dao.BankDAOImpl;
import com.cg.entity.Account;
import com.cg.exception.AccountException;

public class BankServicelmpl implements BankService {
	BankDAO bd=new BankDAOImpl();

	@Override
	public int createaccount(Integer a, Account b)  {
		bd.createaccount(a, b);
		return 0;
	}

	@Override
	public Account getbalance(int accno)  {
		Account bc=bd.getbalance(accno);
		return bc;
		
	}

	@Override
	public Account deposit(int accno,double bal) {
		Account bc=bd.deposit(accno,bal);
		return bc;
		
	}

	@Override
	public Account withdraw(int accno,double bal) {
		Account bc=bd.withdraw(accno,bal);
		return bc;
	}

	@Override
	public boolean validateCusName(String name) throws AccountException {
		Pattern  pattern =Pattern.compile("[A-Z]{1}[a-z]{3,15}");
		Matcher idMatch= pattern.matcher(name);
		if(idMatch.matches())
		{
			return true;
		}
	
		return false;
	}

	
	@Override
	public boolean validateMobileNo(String cellno) throws AccountException {
		Pattern pattern =Pattern.compile("[0-9]{10}");
		Matcher mobMatch= pattern.matcher(cellno);
		if(mobMatch.matches())
		{
			return true;
		}
		
		
		return false;
	}
	
}


	

