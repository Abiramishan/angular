package com.cg.service;


import com.cg.entity.Account;
import com.cg.exception.AccountException;

public interface BankService {
	
	public int createaccount(Integer a,Account b) ;
	
	public Account getbalance(int a) ;
	
	public Account deposit(int accno,double bal) ;
	
	public Account withdraw(int accno,double bal) ;
	
	public boolean validateCusName(String name) throws AccountException;
		
		
		
		public boolean validateMobileNo(String cellno) throws AccountException ;
	

}
