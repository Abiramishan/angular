package com.cg.service;

import com.cg.entity.Account;
import com.cg.entity.Customer;
import com.cg.exception.BankException;

public interface BankService {

	public Account withDraw(Account accno);
	public Account showBalance(long accNo);
	public Account fundTransfer(Account accNo1);
	public void addCustomer(Account acc, Customer cus);
	Account deposit(Account accno);
	boolean validateCustomerName(String customername) throws BankException;
	boolean validateNumber(String number) throws BankException;
	boolean validateAccountno(String accno) throws BankException;
}
