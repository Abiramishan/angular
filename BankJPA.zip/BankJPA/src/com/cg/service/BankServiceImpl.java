package com.cg.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.dao.BankDAO;
import com.cg.dao.BankDAOImpl;
import com.cg.entity.Account;
import com.cg.entity.Customer;
import com.cg.exception.BankException;

public class BankServiceImpl implements BankService {

	BankDAO dao=new BankDAOImpl();

	@Override
	public void addCustomer(Account acc, Customer cus) {
		 dao.addCustomer(acc, cus);
	
	}
	@Override
	public Account deposit(Account accno) {
		return dao.deposit(accno);
		
	}
	@Override
	public Account withDraw(Account accno) {
		dao.withDraw(accno);
		return accno;
	}
	@Override
	public boolean validateCustomerName(String customername) throws BankException {
		Pattern p=Pattern.compile("[A-z]{1}[a-z]{1,9}");
		Matcher m=p.matcher(customername);
		if(m.matches())
		{
			return true;
		}
		else
			
			System.out.println("enter valid name");
		return false;
	}
	@Override
	public boolean validateNumber(String number) throws BankException {
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(number);
		if(m.matches())
		{
			return true;
		}
		else
			
			System.out.println("enter valid number");
		return false;
	}

	@Override
	public boolean validateAccountno(String accno) throws BankException {
		Pattern p=Pattern.compile("[0-9]{11}");
		Matcher m=p.matcher(accno);
		if(m.matches())
		{
			return true;
		}
		else
		
			System.out.println("enter valid accno");
		return false;
	}

	

	@Override
	public Account showBalance(long accNo) {
		return dao.showBalance(accNo);
		 
	}

	@Override
	public Account fundTransfer(Account accNo1) {
		return dao.fundTransfer(accNo1);
		
	}

}
