package com.cg.ui;

import java.util.Scanner;

import com.cg.entity.Account;
import com.cg.entity.Customer;
import com.cg.exception.BankException;
import com.cg.service.BankService;
import com.cg.service.BankServiceImpl;

public class RunMain {

	static Scanner sc=null;
	static BankService service=null;
	private static double balance;
	
	public static void main(String[] args) {
		
		 sc=new Scanner(System.in);
		   service=new BankServiceImpl();
			int choice=0;
			while(true)
			{
				System.out.println("*******Welcome to xyz Bank*******");
				System.out.println("1:Create an Account\t 2:To show the balance of account\n");
				System.out.println("3:Deposit Amount\t 4:Withdraw Amount\n");
				System.out.println("5:FundTransfer\n");
				System.out.println("6:EXIT");
				System.out.println("Enter Your Choice");
				choice=sc.nextInt();
				switch(choice)
				{
				case 1:
					createAccount();
					break;
				case 2:
					showBalance();
					break;
				case 3:
					deposit();
					break;
				case 4:
					withdraw();
					break;
				case 5:
					fundTransfer();
					break;
				
				default:
					break;
				}
				
			}
		}

	private static void createAccount() {
		System.out.println("enter the customername:");
		String customername=sc.next();
		try
		{
		if(service.validateCustomerName(customername))
		{
				System.out.println("enter the customer mobile number");
				String number=sc.next();
				try
				{
				if(service.validateNumber(number))
				{
					System.out.println("enter the customer address");
					String address=sc.next();
					System.out.println("Minimum balance to be deposited to create an account");
					double amount=sc.nextDouble();
					System.out.println("enter the account type");
					String type=sc.next();
					if(amount>3000)
					{
					long accno=(long)(Math.round(Math.random()*10000000+10000000));
					System.out.println(" account created sucessfully and "+" "+"account number generated"+" "+accno);
				    Account acc=new Account(type,amount,accno);
				   
				    Customer cus=new Customer();
				    cus.setAddress(address);
				    cus.setMobileno(Long.parseLong(number));
				    cus.setCustomername(customername);
				    cus.setAccount(acc);
				    service.addCustomer(acc, cus);
				    System.out.println("Details added in the DB");
					}
					else{
						System.out.println("Minimum amount should be 3000 to create account");
					}
					
				}
			}catch(BankException e){
				
			}
		}
		}catch(BankException e){
			
		}	
	}

	private static void showBalance() {
		System.out.println("Enter AccountNo to get Balance");
		long accno=sc.nextLong();
		 Account account=service.showBalance(accno);
			double balance=account.getBalance();
			System.out.println("Balance in the Account:"+ balance);
	}

	private static void deposit() {
		System.out.println("Enter the AccountNo");
		long accNo=sc.nextLong();
		
		Account acc=service.showBalance(accNo);
		double balance=acc.getBalance();
		System.out.println("Enter Amount to be Deposited");
		double amount=sc.nextDouble();
		String type = "savings";
		 balance=balance+amount;
		 Account a=new Account(type,balance,accNo);
		 Account acc1=service.deposit(a);
		System.out.println("Amount Succesfully Deposited:"+acc1);	
	}

	private static void withdraw() {
		System.out.println("Enter the AccountNo");
		long accNo=sc.nextLong();
		
		Account acc=service.showBalance(accNo);
		double balance=acc.getBalance();
		System.out.println("Enter Amount to be withdraw");
		double amount=sc.nextDouble();
		String type = "savings";
		 balance=balance-amount;
		 Account a=new Account(type,balance,accNo);
		 Account acc1=service.deposit(a);
		System.out.println("Amount Succesfully Deposited:"+acc1);	
		
	}

	private static void fundTransfer() {
		System.out.println("Enter the Sender AccountNo");
		long accNo1=sc.nextLong();
		System.out.println("Enter the reciepent AccountNo");
		long accNo2= sc.nextLong();
		Account acc=service.showBalance(accNo1);
		System.out.println("Balance= "+acc.getBalance());
		double balance=acc.getBalance();
		System.out.println("Enter amount to be transfered");
		double balance1=sc.nextDouble();
		String type = "savings";
		double amount=balance-balance1;
		acc.setBalance(amount);
		Account a1=new Account(type,amount,accNo1);
		service.withDraw(a1);
		Account a2=service.showBalance(accNo2);
		System.out.println("Balance= "+a2.getBalance());
		double amount1=a2.getBalance();
		double amt1=amount1+balance1;
		a2.setBalance(amt1);
		String type1 = "savings";
		Account a3=new Account(type1,amt1,accNo2);
		service.deposit(a3);
		System.out.println("Amount Received= "+a3.getBalance());	
	}
}
