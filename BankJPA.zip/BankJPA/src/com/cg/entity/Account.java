package com.cg.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="account_detail")

public class Account  implements Serializable {
 
	@Id
	@Column(name="Account_No")
	private long accountno;
	@Column(name="Account_Type")
	private String accounttype;
	@Column(name="Account_Balance")
	private double balance;
	
	@OneToOne(mappedBy="account")
	private Customer customer;
	
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Account(String accounttype, double balance, long accountno) {
		super();
		this.accounttype = accounttype;
		this.balance = balance;
		this.accountno = accountno;
	}
	
	public String getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public long getAccountno() {
		return accountno;
	}
	public void setAccountno(long accountno) {
		this.accountno = accountno;
	}
	@Override
	public String toString() {
		return "Account [accounttype=" + accounttype + ", balance=" + balance + ", accountno=" + accountno + "]";
	}
	
	
}
