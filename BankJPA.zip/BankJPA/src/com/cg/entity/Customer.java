package com.cg.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="customer_detail")
public class Customer  implements Serializable{

	@Id
	@Column(name="Customer_MobileNo")
	private long mobileno;
	@Column(name="Customer_Name")
	private  String customername;
	
	@Column(name="Customer_Address")
	private String address;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="Account_No")
	private Account account;
	
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public long getMobileno() {
		return mobileno;
	}
	public void setMobileno(long mobileno) {
		this.mobileno = mobileno;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Customer [ customername=" + customername + ", mobileno="
				+ mobileno + ", address=" + address + "]";
	}
	
	

}
