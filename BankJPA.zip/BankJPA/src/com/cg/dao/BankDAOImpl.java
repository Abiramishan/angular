package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Account;
import com.cg.entity.Customer;

public class BankDAOImpl implements BankDAO {

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("myunit");
	EntityManager em = factory.createEntityManager();

	@Override
	public void addCustomer(Account acc, Customer cus) {
		em.getTransaction().begin();
		em.persist(cus);
		em.getTransaction().commit();
		
		em.getTransaction().begin();
		em.persist(acc);
		em.getTransaction().commit();
	}
	@Override
	public Account deposit(Account accno) {
		em.getTransaction().begin();
		em.merge(accno);
		  em.getTransaction().commit();
		return accno;
	}

	@Override
	public Account withDraw(Account accno) {
		em.getTransaction().begin();
		em.merge(accno);
		em.getTransaction().commit();
		return accno;
	}
	@Override
	public Account showBalance(long accNo) {
		em.getTransaction().begin();
		Account acc=em.find(Account.class, accNo);
		em.getTransaction().commit();
		return acc ;
	}

	@Override
	public Account fundTransfer(Account accNo1) {
		em.getTransaction().begin();
		 em.merge(accNo1);
		em.getTransaction().commit();
		return accNo1;
	}
}
