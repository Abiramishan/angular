package com.cg.dao;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Account;


public class BankDAOImpl implements BankDAO
{

	EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em=factory.createEntityManager();
	@Override
	public void createaccount(Integer a, Account b)  {
	em.getTransaction().begin();
	em.persist(b);
	em.getTransaction().commit();
	em.close();
	factory.close();
		
	}
	@Override
	public Account getbalance(int a)  {

		em.getTransaction().begin();
        Account update = em.find(Account.class, a);
		return update;
	}
	@Override
	public Account deposit(int accno, double bal)  {
		
		em.getTransaction().begin();
        Account update = em.find(Account.class, accno);
                double balance1=(update.getBalance()+bal);
        update.setBalance(balance1);
        em.getTransaction().commit();
        em.close();
        return update;
	}
	@Override
	public Account withdraw(int accno, double bal){
		em.getTransaction().begin();
        Account update = em.find(Account.class, accno);
        if(bal<update.getBalance()){
        double balance1=(update.getBalance()-bal);
        update.setBalance(balance1);
        em.getTransaction().commit();
        em.close();
        return update;
        
        }
        else{
        	em.getTransaction().commit();
	        em.close();
        	return null;
        }
	}
	
		
		
	
}
