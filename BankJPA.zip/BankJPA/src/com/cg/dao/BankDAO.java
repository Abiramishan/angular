package com.cg.dao;
import com.cg.entity.Account;
public interface BankDAO {

	public void createaccount(Integer a,Account b) ;
	public Account getbalance(int a);
	public Account deposit(int accno,double bal) ;
	public Account withdraw(int accno,double bal) ;
	
}
