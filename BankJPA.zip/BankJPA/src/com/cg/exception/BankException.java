package com.cg.exception;

public class BankException extends Exception {

	public BankException(long accno) {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
