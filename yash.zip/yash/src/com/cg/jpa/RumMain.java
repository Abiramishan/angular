package com.cg.jpa;

import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.cg.entity.Bank;
import com.cg.service.BankService;
import com.cg.service.BankServiceImpl;

public class RumMain {
	static BankService bs=null;
	static Scanner sc=null;
public static void main(String[] args) throws Exception {
	sc=new Scanner(System.in);
	bs=new BankServiceImpl();
	while(true){
	System.out.println("Welcome to XYZ Bank");
	System.out.println("press 1 to Crate Account\n 2 to Show Balance\n 3 to Deposit Amount \n 4 to WidthDraw\n 5 to Transfer Fund");
	int choice=sc.nextInt();
	switch(choice){
	case 1:
		createaccount();
		break;
	case 2:
		showbalance();
		break;
	case 3:
		depostit();
		break;
	case 4:
		widthdraw();
		break;
	case 5:
		transfer();
		break;
	}
	}
	
}

private static void createaccount() {
	Random rnd=new Random();
	int accno=rnd.nextInt(100000);
	String ifsccode="IOB2563";
	System.out.println("Enter Your Name:");
	String name=sc.next();
	System.out.println("Enter your MobileNumber");
	String mobileno=sc.next();
	System.out.println("Enter Account Type:\n(saving/Current)");
	String acctype=sc.next();
	System.out.println("Enter Amount to Deposit");
	int balance=sc.nextInt();
	Bank bn=new Bank(accno,name,mobileno,balance,ifsccode,acctype);
	bs.createaccount(bn);
}
private static void showbalance() {
	System.out.println("Enter your Account Number:");
	int sbno=sc.nextInt();
	List<Bank> b=bs.showbalance(sbno);
	for(Bank Data:b){
		System.out.println("Account Holder Name\t" +Data.getName());
		System.out.println("Account Number\t"+Data.getAccnumber());
		System.out.println("Account Balance\t"+Data.getBalance());
		
	
	}
}
	private static void depostit() {
		System.out.println("Enter your Account Number to Deposit Amount");
		int daccno=sc.nextInt();
		System.out.println("Enter Amount to Deposit");
		int dbalance=sc.nextInt();
		Bank b=bs.deposit(daccno,dbalance);
		System.out.println("Deposit Successfully Completed");
		System.out.println("Account number="+b.getAccnumber());
		System.out.println("Account Holder Name="+b.getName());
		System.out.println("Account Updated Balance="+b.getBalance());
	}
	private static void widthdraw()throws Exception {
		System.out.println("Enter Account Number to WidthDraw Amount");
		int waccno=sc.nextInt();
		System.out.println("Enter Amount to widthdraw");
		int wbalance=sc.nextInt();
		Bank b=bs.widthdraw(waccno,wbalance);
		try{
			if(b==null){
				 throw new Exception();
		}else{
			System.out.println("After Withdraw You have="+b.getBalance());
		}
		}
		catch(Exception e){
		System.out.println("Insufficient Account Balance");
		}
		}
	private static void transfer() {
		System.out.println("Enter your Account Number");
		int T1accno=sc.nextInt();
		System.out.println("Enter Account Whome You want to Transfer");
		int T2accno=sc.nextInt();
		Bank b=bs.transfer(T1accno,T2accno);
	}
}
