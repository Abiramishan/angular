package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.entity.Bank;

public class BankDaoImpl implements BankDao {

	@Override
	public void createaccount(Bank bn) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		em.persist(bn);
		em.getTransaction().commit();
		em.close();
		factory.close();
	}

	@Override
	public List<Bank> showbalance(int sbno) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		String str="SELECT ab FROM Bank ab WHERE ab.accnumber=:num";
		TypedQuery<Bank> query=em.createQuery(str,Bank.class);
		query.setParameter("num",sbno);
		List<Bank> e=query.getResultList();
		return e;
		
	}

	@Override
	public Bank deposit(int daccno, int dbalance) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
	        Bank update = em.find(Bank.class, daccno);
	        int balance1=(update.getBalance()+dbalance);
	        update.setBalance(balance1);
	        em.getTransaction().commit();
	        em.close();
			return update;
	}

	@Override
	public Bank widthdraw(int waccno, int wbalance) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
	        Bank update = em.find(Bank.class, waccno);
	        if(wbalance<update.getBalance()){
	        int balance1=(update.getBalance()-wbalance);
	        update.setBalance(balance1);
	        em.getTransaction().commit();
	        em.close();
	        return update;
	        
	        }
	        else{
	        	em.getTransaction().commit();
		        em.close();
	        	return null;
	        }
	        
		
	}

	@Override
	public Bank transfer(int t1accno, int t2accno) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		return null;
	}

}
