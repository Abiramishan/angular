package com.cg.dao;

import java.util.List;

import com.cg.entity.Bank;

public interface BankDao {

	public void createaccount(Bank bn);

	List<Bank> showbalance(int sbno);

	public Bank deposit(int daccno, int dbalance);
	public Bank widthdraw(int waccno, int wbalance);
	public Bank transfer(int t1accno, int t2accno);
}
