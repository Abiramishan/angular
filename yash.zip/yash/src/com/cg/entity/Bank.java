package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Bank {
	@Id
private int accnumber;
private String name;
private String mobileno;
private int balance;
private String ifsccode;
private String acctype;
public Bank(int accnumber, String name, String mobileno, int balance,
		String ifsccode, String acctype) {
	super();
	this.accnumber = accnumber;
	this.name = name;
	this.mobileno = mobileno;
	this.balance = balance;
	this.ifsccode = ifsccode;
	this.acctype = acctype;
}
public Bank() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Bank [accnumber=" + accnumber + ", name=" + name + ", mobileno="
			+ mobileno + ", balance=" + balance + ", ifsccode=" + ifsccode
			+ ", acctype=" + acctype + "]";
}
public int getAccnumber() {
	return accnumber;
}
public void setAccnumber(int accnumber) {
	this.accnumber = accnumber;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getMobileno() {
	return mobileno;
}
public void setMobileno(String mobileno) {
	this.mobileno = mobileno;
}
public int getBalance() {
	return balance;
}
public void setBalance(int balance) {
	this.balance = balance;
}
public String getIfsccode() {
	return ifsccode;
}
public void setIfsccode(String ifsccode) {
	this.ifsccode = ifsccode;
}
public String getAcctype() {
	return acctype;
}
public void setAcctype(String acctype) {
	this.acctype = acctype;
}

}
