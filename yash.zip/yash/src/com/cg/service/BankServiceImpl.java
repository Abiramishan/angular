package com.cg.service;

import java.util.List;

import com.cg.dao.BankDao;
import com.cg.dao.BankDaoImpl;
import com.cg.entity.Bank;

public class BankServiceImpl implements BankService{
BankDao bd=new BankDaoImpl();
	@Override
	public void createaccount(Bank bn) {
		bd.createaccount(bn);
		
	}
	@Override
	public List<Bank> showbalance(int sbno) {
		List<Bank> e=bd.showbalance(sbno);
		return e;
		
	}
	@Override
	public Bank deposit(int daccno, int dbalance) {
		Bank e=bd.deposit(daccno,dbalance);
		return e;
	}
	@Override
	public Bank widthdraw(int waccno, int wbalance) {
		Bank e=bd.widthdraw(waccno,wbalance);
		return e;
	}
	@Override
	public Bank transfer(int t1accno, int t2accno) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
