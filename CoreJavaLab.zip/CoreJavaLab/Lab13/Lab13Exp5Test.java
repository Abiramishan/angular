import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class Lab13Exp5Test {

	 Lab13Exp5 fact;
	 @Test 
	 public void test()
	 {
		 fact=new  Lab13Exp5();
		 assertEquals(720, fact.fact(6));
	 }
}
