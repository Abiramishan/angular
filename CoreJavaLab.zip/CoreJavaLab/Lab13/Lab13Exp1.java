@FunctionalInterface
public interface Lab13Exp1 {
void sqaure(int a,int b);
}
