import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Lab10Exp1 implements Runnable {
	
		@Override
		public void run() {
			
			
			int count=0;
			try {
				 BufferedReader in= new BufferedReader(new FileReader("java.txt"));
				 BufferedWriter out=new BufferedWriter(new FileWriter("sample.txt"));
				 
				String line;
				while((line=in.readLine())!=null)
				{
				for(char ch:line.toCharArray())
				{
					count++;
					if(count==10)
					{
						System.out.println("10 characters copied");
						Thread.sleep(10000);
					}
					
					else
					{
						out.write(ch+"\n");
						System.out.println(ch);
					}
					
				}
				count=0;
				out.append(System.lineSeparator());
			}
			in.close();
			out.close();
			} catch (IOException |InterruptedException e)
			{
				
				e.printStackTrace();
			}
				}

		
}
