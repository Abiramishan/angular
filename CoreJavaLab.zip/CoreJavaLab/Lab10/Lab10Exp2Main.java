
public class Lab10Exp2Main {
	public static void main(String[] args) {
		Runnable t1=new Lab10Exp2();
		Thread t2=new Thread(t1);
		t2.start();
	}
}
