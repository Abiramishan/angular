package com.cg.emp.ui;

import java.time.LocalDate;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;



import com.cg.emp.enttity.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.service.EmployeeService;
import com.cg.emp.service.EmployeeServiceImpl;

public class RunMain
{
	static Scanner sc=null;
	static EmployeeService empService=null;
	
public static void main(String[] args) throws EmployeeException
{
	sc=new Scanner (System.in);
	empService=new EmployeeServiceImpl();
	int choice=0;
	while(true)
	{
		System.out.println("What Do Want To Do?");
		System.out.println("1:Add Emp\t2:Fetch All Emp\n");
		System.out.println("3:Delet Emp \t4:Search Emp By id\n");
		System.out.println("5:Sort Emp By Name \\t6 :Update Emp\\n ");
		System.out.println("7:EXIT\n");
		System.out.println("Enter UR Choice");
		choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			addEmployee();
			break;
		case 2:
			fetchAllEmp();
			break;
			
		case 3:
			deleteEmp();
			break;
		case 4:
			searchByEmployeeId();
			break;
		case 5:
			sortEmpByName();
			break;
		case 6:
			updateEmp();
		case 7:
			default:
				
		}
	}
}

public static void addEmployee()
{
while(true)
{
	System.out.println("Enter Emp Id");
	String eid=sc.next();
	try
	{
		if(empService.validateEmpId(eid))
		{
			
			while(true)
			{
				System.out.println("Enter Employee Name:");
				String name=sc.next();
				try
				{
					if(empService.validateEmpName(name))
					{
						System.out.println("Emter Emp sal: ");
						float empSal=sc.nextFloat();
						Employee employee=new Employee(name, Integer.parseInt(eid), empSal, LocalDate.now());					
						empService.addEmployee(employee);
						System.out.println("Employee Added");
						break;
					}
				}catch(Exception e) {}
			}
		}
	}catch(Exception exe) {}
	break;
	
}}
public static void fetchAllEmp()
{
	empService=new EmployeeServiceImpl();
	HashMap<Integer,Employee> hs=empService.fetchAllEmp();
	Collection<Employee> c = hs.values();
	Iterator<Employee> it=c.iterator();
	while(it.hasNext())
	{
		//System.out.println(it.hasNext());
		Employee ee = it.next();
		System.out.println(ee.getEmpId()+""+ee.getEmpName()+""+ee.getEmpSal()+""+ee.getEmpDoj());
	
	}
	
	
}
public static void  searchByEmployeeId() throws EmployeeException
{
	while(true)
	{
		System.out.println("enter emp id");
		String eid=sc.next();
		
			if(empService.validateEmpId(eid))
			{
				while(true)
				{
					
					if((empService.getEmpById(Integer.parseInt(eid)))!=null)
					{
						int a=Integer.parseInt(eid);
						Employee e=empService.getEmpById(a);
						System.out.println("Employee Details \n"+e.getEmpName()+""+e.getEmpId()+""+e.getEmpSal()+""+e.getEmpDoj());
						break;
					}/*catch(Exception e) {
						//System.out.println("id number is worng");
						//throw new EmployeeException(eid);
						break;
					}*/
					else
					{
						throw new EmployeeException(eid);

					}
				}
			}
			
		}
	}
public static void deleteEmp()
{
	while(true)
	{
		System.out.println("Enter Emp Id");
		String eid=sc.next();
		try
		{
			if(empService.validateEmpId(eid))
			{
				
				while(true)
				{
				
					try
					{
						
						int a = Integer.parseInt(eid);
						 empService.deleteEmp(a);
							System.out.println("Employee Deleted");
							break;
						
					}catch(Exception e) {}
				}
			}
		}catch(Exception exe) {}
		break;
		
	}

}
public static void sortEmpByName()
{
empService.sortEmpName();
}

public static void  updateEmp() throws NumberFormatException, EmployeeException 
{	
	
	while(true)
	{
		System.out.println("Enter Emp Id");
		String eid=sc.next();
	
			if(empService.validateEmpId(eid))
			{
				System.out.println("enter the name");
				String ss=sc.next();
				if(empService.validateEmpName(ss))
				{
				while(true)
				{
					System.out.println("enter the salary");
					float sa=sc.nextFloat();
					
					empService.updateEmp(ss,Integer.parseInt(eid),sa);
					break;
				}
				}
			}
	break;
	}
}

}
	


