package com.cg.emp.exception;

public class EmployeeException extends Exception {

	public EmployeeException(String eid) {
		super(eid);
		// TODO Auto-generated constructor stub
	}

	

}
