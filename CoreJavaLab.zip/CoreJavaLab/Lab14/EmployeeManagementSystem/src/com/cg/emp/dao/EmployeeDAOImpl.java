package com.cg.emp.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import com.cg.emp.enttity.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.util.CollectionUtil;

public class EmployeeDAOImpl implements EmployeeDAO {

	@Override
	public int addEmployee(Employee ee) throws EmployeeException {

		CollectionUtil.addEmp(ee);
		return ee.getEmpId();
	}

	@Override
	public HashMap<Integer,Employee> fetchAllEmp() {
		HashMap<Integer,Employee> hs=CollectionUtil.fetchAllEmp();
		return hs;
	}

	@Override
	public Employee getEmpById(int empId) {
		Employee emp=CollectionUtil.getEmpById(empId);
		return emp;
	}


	@Override
	public int deleteEmp(int empId) {
		CollectionUtil.deleteEmp(empId);
	return empId;
	}

	@Override
	public Employee updateEmp( String newName,int empId, float newSal) {
		Employee e=CollectionUtil.updateEmp(newName,empId,newSal);
		return e;
	//	int u=CollectionUtil;
		
	}

	@Override
	public boolean validateEmpName(String name) throws EmployeeException {
		// TODO Auto-generated method stub
		return false;
	}

	/*@Override
	public Employee searchEmpByName(String name) {
		Employee e=CollectionUtil.searchEmpByName(name);
		return null;*/
	//}

	@Override
	public List<Employee> sortEmpName() {
		List<Employee> sort=CollectionUtil.sortEmpName();
		return sort;
	}

	@Override
	public Employee searchEmpByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

}
