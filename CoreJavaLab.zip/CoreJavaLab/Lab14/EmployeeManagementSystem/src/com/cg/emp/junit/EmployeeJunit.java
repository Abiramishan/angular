package com.cg.emp.junit;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

import com.cg.emp.dao.EmployeeDAO;
import com.cg.emp.dao.EmployeeDAOImpl;
import com.cg.emp.enttity.Employee;
import com.cg.emp.exception.EmployeeException;

class EmployeeJunit {

	static EmployeeDAO empdao=null; 
	@BeforeClass
		public static void setUp()
		{
			empdao=new EmployeeDAOImpl();
		} 
	@Test
		public void addEmpTest() throws EmployeeException
		{
			Assert.assertEquals(111, empdao.addEmployee(
					new Employee("aaa",111,1111.0F,
							LocalDate.now())));
		} 
	@Test
	void test() {
		fail("Not yet implemented");
	}

}
