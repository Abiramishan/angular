package com.cg.emp.util;

import java.util.List;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
//import java.util.HashSet;

import com.cg.emp.enttity.Employee;

public class CollectionUtil  {
	private static HashMap<Integer,Employee> emp1=new HashMap<Integer,Employee>();
	static List<Employee>list;
	//private static Object ;
	
//private  static HashSet<Employee> empSet=new HashSet<Employee>();
    static

	{
    	emp1.put(1001,new Employee("Udayram",1001,45000.0F,LocalDate.of(2019,Month.FEBRUARY, 4)));
    	emp1.put(1002,new Employee("Ram",1002,45000.0F,LocalDate.of(2019, Month.JANUARY, 04)));
    	emp1.put(1003,new Employee("Irfan",1003,45000.0F,LocalDate.of(2019,Month.DECEMBER, 04)));
    	emp1.put(1004,new Employee("Charan",1004,45000.0F,LocalDate.of(2019,Month.JANUARY, 05)));
    	list=new ArrayList<Employee>();
    	list.add(new Employee("Udayram",1001,45000.0F,LocalDate.of(2019,Month.FEBRUARY, 4)));
    	list.add(new Employee("Ram",1002,45000.0F,LocalDate.of(2019, Month.JANUARY, 04)));
    	list.add(new Employee("Irfan",1003,45000.0F,LocalDate.of(2019,Month.DECEMBER, 04)));
    	list.add(new Employee("Charan",1004,45000.0F,LocalDate.of(2019,Month.JANUARY, 05)));
    	
    	
		
	}
	public static void addEmp(Employee emp)
	{
		emp1.put(emp.getEmpId(),emp);
	}
	public static HashMap<Integer,Employee> fetchAllEmp()
	
	{
	return 	emp1;
	}
	public static Employee getEmpById(int empId)
	{
		Employee e=emp1.get(empId);
		return e;
		
	}
	public static Employee searchEmpById(int name)
	{	
		Employee e=emp1.get(name);
		return e;
	}
	public static int deleteEmp(int empId)
	{
		emp1.remove(empId);
		return empId;
		
	}
	public static List<Employee> sortEmpName() 
	
	{	Collections.sort(list,new SortName());
	for(Employee movie:list)
	{
		System.out.println(movie.getEmpName()+" "+movie.getEmpId()+" "+movie.getEmpSal()+" "+movie.getEmpDoj());
	}
	return list;
		
		
	}
	
	 public static Employee updateEmp(String newName,int empId, float newSal)
	 {
		 emp1.put(empId,new Employee(newName,empId,newSal,LocalDate.now()));
		 Employee ee=emp1.get(empId);
		return ee;
		 
		 
	 }
	
}

