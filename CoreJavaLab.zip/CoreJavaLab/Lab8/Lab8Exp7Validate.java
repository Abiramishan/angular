import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Lab8Exp7Validate {

	public boolean validate(String empname)
	{
		Pattern pattern = Pattern.compile("[A-Z]{1}[a-z]{2,10}_job");
		Matcher empnameMatch = pattern.matcher(empname);
		if(empnameMatch.matches())
		{
			return true;
		}
		return false;
	}
	
}
