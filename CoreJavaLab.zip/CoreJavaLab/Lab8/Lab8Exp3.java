import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Lab8Exp3 {
public static void main(String[] args) {
	try
	{
		int lines=0,chars=0,word=0;
		int code=0;
		String s=" my name is shama";
		char buffer[]=new char[s.length()];
		s.getChars(0, s.length(), buffer, 0);
		FileWriter f=new FileWriter("sample.txt");
		f.write(buffer);
		f.close();
		FileReader f1=new FileReader("sample.txt");
		BufferedReader b=new BufferedReader(f1);
		String t;
		while((t=b.readLine())!=null)
		{
			int c=0;
			c++;
			System.out.println(c+t);
		}
		f1.close();
		FileInputStream fis=new FileInputStream("sample.txt");
		while((fis.available())!=0)
		{
			code=fis.read();
			if(code!=10)
				chars++;
			if(code==32)
				word++;
			if(code==13)
				lines++;
			word++;
		}
		System.out.println("no of character="+chars);
		System.out.println("no of words"+(word+1));
		System.out.println("no of the lines "+(lines+1));
	}
	catch(FileNotFoundException e)
	{
		System.out.println("can not find the specified file");
	}
	catch(IOException i)
	{
		System.out.println("can not read file");
	}
}
}
