import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Lab8Exp2 {
public static void main(String[] args) throws IOException {
	int c=0;
	String s="my \n name \n is \n abirami\n";
	char buffer[]=new char[s.length()];
	s.getChars(0, s.length(),buffer,0);
	FileWriter f1=new FileWriter("java.txt");
	f1.write(buffer);
	f1.close();
	FileReader f2=new FileReader("java.txt");
	BufferedReader b=new BufferedReader(f2);
	String t;
	while((t=b.readLine())!=null)
	{
		c++;
		System.out.println(c++);
		
	}
	f2.close();
	
}

}
