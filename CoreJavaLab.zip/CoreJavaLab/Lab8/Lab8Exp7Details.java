import java.util.Scanner;

public class Lab8Exp7Details {

	public void empdetails()
	{
		System.out.println("Enter the Details");
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the University");
		String univ = s.next();
		System.out.println("cgpa");
		double cgpa = s.nextDouble();
	}
	
}
