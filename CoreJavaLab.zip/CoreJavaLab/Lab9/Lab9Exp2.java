import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Lab9Exp2 {
static void characterCount(String inputString)
{
	HashMap<Character,Integer> charcountMap=new HashMap<Character,Integer>();
	char[] strArray= inputString.toCharArray();
	for(char c: strArray)
	{
		if(charcountMap.containsKey(c))
		{
			charcountMap.put(c,charcountMap.get(c)+1);
			
		}
		else 
		{
			charcountMap.put(c, 1);
			
		}
	}
		for(Map.Entry entry: charcountMap.entrySet())
		{
			System.out.println(entry.getKey()+" "+entry.getValue());
		}
}
public static void main(String[] agrs)
{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the String");
	String str=sc.next();
	characterCount(str);
	sc.close();
}


}
