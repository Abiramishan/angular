import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class Lab11Main {
	public static void main(String args[]) throws IOException, InterruptedException {
		BufferedReader in = null;
		BufferedWriter out = null;
		Runnable worker = null;
		in = new BufferedReader(new FileReader("java.txt"));
		Executor executor = Executors.newSingleThreadExecutor();
		worker = new Lab11(in,out);
		executor.execute(worker);
}
}
