import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Lab11 implements Runnable {


		BufferedReader br;
		BufferedWriter wr;
		public Lab11(BufferedReader in, BufferedWriter out) throws InterruptedException
		
		{
			this.br = null;
			this.wr = null;

	try{
		br = new BufferedReader(new FileReader("java.txt"));
		wr = new BufferedWriter(new FileWriter("test.txt"));

			String line;
			int count = 0;
			while((line= br.readLine()) != null)
	{
	wr.write(line);
	for(char ch:line.toCharArray())
	{
	count++;
	if(count == 10)
	{System.out.println("10 Characters are copied");
	}}
	Thread.sleep(5000);
	 }
	br.close();
	wr.close();}
	catch(IOException e)

	{
	e.printStackTrace();
	}

		}
		@Override
		public void run() {
			// TODO Auto-generated method stub
			
		}}


