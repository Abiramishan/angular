package com.cg;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {
	Login login;
	@RequestMapping("/showForm")
	public String displayFrom(Model model)
	{
		
		model.addAttribute("login",login);
		return "login";
	}
	@RequestMapping(value="/checklogin")
	public String checkMtd(Login login)
	{
		if(login.getUsername().equals(login.getPassword()))
		{
			return "success";
		}
		return "login";
		
	}

}
