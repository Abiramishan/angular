package java.io;

public class InputStreamRead {

}
