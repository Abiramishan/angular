import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class MainComparator {
public static void main(String[] args) {
	ArrayList<TraineeDemo> list=new ArrayList<TraineeDemo>();
	list.add(new TraineeDemo(5,"Bahubali"));
	list.add(new TraineeDemo(3,"orange"));
	list.add(new TraineeDemo(2,"aarya2"));
	
	Collections.sort(list,new ComparatorEx());
	/*Iterator iterator=list.iterator();
	while(iterator.hasNext())
	{
		System.out.println(iterator.next());
		
	}*/
	for(TraineeDemo movie:list)
	{
		System.out.println(movie.id+"  "+movie.name);
	}
}
}
