
public class Lab1Exp1 {
	public int calculateSum(int n)
	{
		int sum=0;
		for(int i=0;i<=n;i++)
		{
			if(i%3==0||i%5==0)
			{
				sum=sum+i;
				//System.out.println("Sum is ="+sum);
			}
			
		}
		System.out.println("Sum is ="+sum);
		return sum;
	}
public static void main(String[] args) {
	Lab1Exp1 v=new Lab1Exp1();
	v.calculateSum(10);
	
}
}
