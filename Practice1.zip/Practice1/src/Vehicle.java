
public class Vehicle extends Car1 {

	@Override
	void speed() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void capacity() {
		// TODO Auto-generated method stub
		
	}
	void flue() {
		System.out.println("flue");
	}

	public Vehicle() {
		super();
	
		// TODO Auto-generated constructor stub
		System.out.println("defined");
	}
	
	
	public static void main(String[] args) {
		Car1 v=new Vehicle();
		//v.flue();
		v.capacity();
	}

}
