
public class Lab5Exp5 extends Exception {
public Lab5Exp5(String age)
{
	super(age);
	System.out.println("age should not be lessthen or equal to 15");
}

}
