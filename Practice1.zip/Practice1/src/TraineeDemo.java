
public final class TraineeDemo {
 int id;
String name;
final int a=9;
public TraineeDemo(int id, String name) {
	super();
	this.id = id;
	this.name = name;
	//a++;
}
final void mtd()
{
	System.out.println("mtd");
}

}
