
public class All {
public void director(String a)
	{
	System.out.println("Name:"+a);
	}
public void genre(String b)
	{
	System.out.println("Genre:"+b);
	}
public void yearReleased(int i)
	{
	System.out.println("Released year:"+i);
	}
public void artist(String c)
{
	System.out.println("Name of the artist:"+c);
	}
public static void main(String[] args) {
	Jbook i=new Jbook();
	i.setId(1111);
	i.setTitle("str2");
	i.setCopies(200);
	i.setAuthor("jai");
	i.setYearpublished(2019);
	System.out.println("Id :"+i.getId());
	System.out.println("Title:"+i.getTitle());
	System.out.println("Copies:"+i.getCopies());
	System.out.println("Author:"+i.getAuthor());
	System.out.println("published:"+i.getYearpublished());
	All a=new All();
	a.director("abi");
	a.artist("shama");
	a.yearReleased(2019);
	a.genre("Albums");
}
}
