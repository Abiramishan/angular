
public class TrycatchDemo
{
public static void main(String[]args)
{
	
			String str1="Hello";
			String str2=new String("Hello");
			System.out.println(str1.equals(str2)+"is equal");
			System.out.println(str1==str2+"==operatore");
			System.out.println("**********");
			String str3=new String("hello");
			str3=str2;
			
			String str4=new String("hello");
			System.out.println(str1.equals(str3)+"is equal");
			System.out.println(str2==str3+"==operatore");
			str3="hello";
			System.out.println(str2==str3+"==operatore");
}
}
