import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidateCus 
{
public static boolean validateCusname(String cusname)
{
	Pattern p=Pattern.compile("^[A-Z]{1}[a-z]{2,7}");
	Matcher m=p.matcher(cusname);
	if(m.matches())
	{
		return true;
	}
	return false; 
}
public static boolean validateCusid(String cusid)
{
	Pattern pattern=Pattern.compile("[0-8]{5}");
	Matcher choiceMatch=pattern.matcher(cusid);
	if(choiceMatch.matches())
	{
		return true;
	}
	return false; 
}
public static boolean validateCusmobile(String cusmobile)
{
	Pattern pat=Pattern.compile("[0-9]{10}");
	Matcher choi=pat.matcher(cusmobile);
	if(choi.matches())
	{
		return true;
	}
	return false; 
}
public static boolean validateCusmailid(String cusmailid)
{
	Pattern pa=Pattern.compile("^[A-z0-9]+@[a-z](.+)$");
	Matcher cho=pa.matcher(cusmailid);
	if(cho.matches())
	{
		return true;
	}
	return false; 
}
}

