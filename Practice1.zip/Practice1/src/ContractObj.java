
public class ContractObj {
	public ContractObj()
	{	
		this(4,6);
		
		System.out.println("first value");
	}
	public ContractObj(int a, int b)
	{
		this("abi");
		System.out.println("a="+a+ "b="+b);
	}
	public ContractObj(String name)
	{
		System.out.println("name="+name);
	}
	public static void main(String[] args) {
		ContractObj obj=new ContractObj();
		
		
		
		
	}
}
