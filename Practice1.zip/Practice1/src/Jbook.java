
public class Jbook extends Witem{
private int yearpublished;
public int getYearpublished()
{
	return yearpublished;
	
}
public void setYearpublished(int yearpublished)
{
	this.yearpublished=yearpublished;
}
}
