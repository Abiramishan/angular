
public class Section {
 String name;
}
