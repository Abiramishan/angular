import java.util.ArrayList;
import java.util.Collections;

public class RunMovie {
public static void main(String[] args) {
	ArrayList<Movie> list=new ArrayList<Movie>();
	list.add(new Movie(5,"Bahubali",2017));
	list.add(new Movie(3,"orange",2018));
	list.add(new Movie(2,"aarya2",2010));
	for(Movie movie:list)
	{
		System.out.println(movie.getName()+""+movie.getRating()+""+movie.getYear());
	}
	Collections.sort(list);
	System.out.println("after the sort");
	for(Movie movie:list)
	{
		System.out.println(movie.getName()+""+movie.getRating()+""+movie.getYear());
	}
}
}
