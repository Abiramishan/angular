public class OCJP {
public static void main(String[] args) {
	Section s1=new Section();
	s1.name="ASAS";
	Section s2=new Section();
	s2.name="DDS";
	System.out.println(s1.name);
	System.out.println(s2.name);
	
//	Predicate<String>aSection=(s)->s=="summer";
	//System.out.println(aSection.test(new String ("ASAS")));
	
}
}
