import java.util.Scanner;

public class ExcepMain {
public static void main(String[] args) throws Exception
{
	String name;
	String id;
	Excep excep=new Excep();
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the value");
	sc.nextInt();
	int c;
	c=sc.nextInt();
	switch(c)
	{
	case 1:
	
		
		System.out.println("enter the name");
		String s=sc.nextLine();
		boolean result=excep.Exname(s);
		if(result==true)
		{
			System.out.println("true");
		} 
		else {
				throw new InvalidException(s);
		}
	System.out.println("enter the id");
	
	String  s1=sc.nextLine();
	
	boolean result1=excep.Exid(s);
	if(result==true)
	{
		System.out.println("true");
	}
	else
	System.out.println("false");
	
	
	case 2:
	{
		break;
	}
	}
	sc.close();
}
}
