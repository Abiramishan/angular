
public class Lab1Exp3 {
	static boolean f=true;
	public boolean checkNumber(int number)
	{
		
		int t=0;
		while(number>=1)
		{
			t=number%10;
			number=number/10;
			if(t<=number%10)
			{
				f=false;
			}
		}
		
		return f;	
	}
	public static void main(String[] args) 
	{
		Lab1Exp3 v=new Lab1Exp3();
		v.checkNumber(123);
		if(f==true)
		{
			System.out.println("increase value");
			
	}
		else
		{
			System.out.println("unincrease order");
		}
	}

}
