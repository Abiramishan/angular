
public class Lab5Exp3 {
boolean findPrime(int n)
{
	boolean flag=true;
	int i;
	for(i=2;i<=n/2;i++)
	{
	if(n%i==0)
	{
		flag=false;
		break;
	}
	}
if(flag==false)

	return false;
	

return true;
}
}
