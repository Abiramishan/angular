
public class Car2 implements Vehic,Vehic1 {

	@Override
	public void ful() {
		// TODO Auto-generated method stub
		System.out.println("ful");
	}

	@Override
	public void flue() {
		// TODO Auto-generated method stub
		System.out.println("flue");
		
	}

	@Override
	public void speed() {
		// TODO Auto-generated method stub
		System.out.println("speed");
	}
	public static void main(String[] args) {
		Car2 v=new Car2();
		v.speed();
		v.flue();
		v.ful();
		System.out.println("final");
	}
	
}
