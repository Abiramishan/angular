
public  class Demo1 extends TraineeDemo()
{
	void mtd()
	{
		System.out.println("mtd");
	}

}
