
public class App {
	int gears;
	int capacity;
	String mode;
	
	App()
	{
		//this(6);
		System.out.println("default contructtor-app");
		
	}

	App(int gears)
	{
		this();
		System.out.println("no of gear:"+gears);
	}
	
	public App(int gears, int capacity, String mode) {
		super();
		this.gears = gears;
		this.capacity = capacity;
		this.mode = mode;
		System.out.println(this.gears+" "+this.capacity);
	}

	public static void main(String[] args) {
		new App(5,5,"swift");
		//new App(9);
		//App app1=new App(5);
	}
} 
