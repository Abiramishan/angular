
public class Smaple {
public static void main(String[] args) {
	byte a=127;
	byte b=124;
	byte r=(byte)(a-b);
	System.out.println(r);
}
}
