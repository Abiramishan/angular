
public class Account {
public void withDraw()
{
	System.out.println("withDraw");
}
public void deposit()
{
	System.out.println("deposit");
}
public static void main(String[] args) {
	Account a=new Account();
	a.withDraw();
	a.deposit();
}
}
