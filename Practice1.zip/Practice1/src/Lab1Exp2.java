
public class Lab1Exp2 
{
	public int calculateDifference(int n)
	{
		int sum=0, s=0;
		for(int i=0;i<=n;i++)
		{
			sum+=i;
			s+=(i*i);
		}
		sum*=sum;
		sum=s-sum;
		System.out.println("difference num ="+sum);
		return sum;
	}
	public static void main(String[] args) {
		Lab1Exp2 v=new Lab1Exp2();
		v.calculateDifference(5);
	}

}
