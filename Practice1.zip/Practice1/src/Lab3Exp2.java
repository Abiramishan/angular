import java.util.Arrays;

public class Lab3Exp2 {
	public void caseSort(String[] s,int size)
	{
		int temp;
		Arrays.sort(s);
		for(int i=0;i<size;i++)
		{
			s[i]=s[i].toLowerCase();
		}
		if(size%2!=0)
		temp=(size/2)+1;
		else
			temp=size/2;
		for(int j=0;j<temp;j++)
		{
			s[j]=s[j].toUpperCase();
		}
		for(int k=0;k<s.length;k++)
		{
			System.out.println(s[k]+"");
		}
	}
	public static void main(String[] args) {
		Lab3Exp2 str=new Lab3Exp2();
		String[] strArray=new String[] {"d","s","e","a"};
		int size=strArray.length;
		str.caseSort(strArray, size);
	}
	
}