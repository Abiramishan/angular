import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.omg.Messaging.SyncScopeHelper;

import cons.Student;

public class ObjectSerializationDemo {
public static void main(String[] args) throws IOException, ClassNotFoundException  
{
	try(FileOutputStream fos=new FileOutputStream("student");
		ObjectOutputStream oos=new ObjectOutputStream(fos);)
			{
			Student stu=new Student(12,"shama");
			oos.writeObject(stu);
			oos.flush();
			}
	catch(Exception e)
	{
		System.out.println("");
	}
	try(FileInputStream fis=new FileInputStream("student");
			ObjectInputStream ois=new ObjectInputStream(fis);)
	{
		Student stu;
		stu=(Student)ois.readObject();
		System.out.println(stu);
	}

catch(Exception r)

{
	System.out.println("exc ");
}
}
}
