import java.util.Scanner;

public class Lab5Exp4Main {
public static void main(String[] args) {
	System.out.println("enter the name  : ");
	Scanner sc=new Scanner(System.in);
	String s=sc.nextLine();
	
	Lab5Exp4 l=new Lab5Exp4();
	boolean result=l.validName(s);
	if(result==true)
	{
		System.out.println("successful");
	}
	else
	{
		System.out.println("wrong");
	}
	
}
}
