import java.util.Scanner;

public class Lab5Exp2 {
int fibo(int n)
{
	if(n==0)
		return 0;
	else if(n==1)
	{
		return 1;
	}
	else
		return (fibo(n-1)+fibo(n-2));
	
}
public static void main(String[] args) {
	System.out.println("enter the number");
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	Lab5Exp2 f=new Lab5Exp2();
	System.out.println("fibonacci series"+f.fibo(n));
}
}
