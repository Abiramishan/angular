import java.util.Scanner;

import com.cg.eis.exception.EmployeeException;

public class Lab5Exp6 {
	public static void validate(int salary)throws EmployeeException
	{
		if(salary<3000)
		{
			throw new EmployeeException("Exception"+salary);
		}
		else
		{
			System.out.println("Continue with steps");
		}
	} 
	public static void main(String[] args) {
		String salary;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the salary");
		salary=sc.next();
		try
		{
			int ag=Integer.parseInt(salary);
			validate(ag);
		}
			catch(EmployeeException e)
			{
				System.out.println("exc occured");
			}
			sc.close();
		
	}
}
