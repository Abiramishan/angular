
public class Child extends Parent{
	
		int b=12;
		void mtd()
		{
			System.out.println("non defined");
		}
		/*Child()
		{
			System.out.println("child class");
		}*/
		public Child() {
			super();
			super.validate();
			// TODO Auto-generated constructor stub
			System.out.println("child class");
		}

	}

