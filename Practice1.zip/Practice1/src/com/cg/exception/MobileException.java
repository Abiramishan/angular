package com.cg.exception;

import java.util.Map;

public class MobileException extends Exception {
public MobileException(String mobileNo)
{
	super(mobileNo);
	System.out.println("mobile number should be ten digits");
}
}
