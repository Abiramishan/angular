package com.cg.data;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.List;
import java.util.Map.Entry;
import com.cg.bean.Account;

public class MobileData {
Map<String,Account>data;
List<Account>list;
TreeMap<String,Account>tm;

public MobileData()
{
	data=new HashMap<String,Account>();
	data.put("9989765678",new Account("prepaid","abi",200));
	data.put("9989365228",new Account("prepaid","shama",200));
	data.put("9989765228",new Account("prepaid","Mashan",200));
	list=new ArrayList<Account>();
	list.add(new Account("prepaid","abi",200));
	list.add(new Account("prepaid","shama",200));
	list.add(new Account("prepaid","Mashan",200));
	tm=new TreeMap<String,Account>();
	tm.put("9989365228",new Account("prepaid","abi",200));
	tm.put("9989365228",new Account("prepaid","shama",200));
	tm.put("9989765228",new Account("prepaid","Mashan",200));
	System.out.println("Natural Sorting:");
	System.out.println(tm);
	for(Account n:list) {
		System.out.println(n.getAccountType()+" "+n.getCustomerName()+" "+n.getAccountBalance());
	}
	Collections.sort(list);
	System.out.println("Sorting using Account Balance");
	for(Account m: list)
	{
		System.out.println(m.getAccountType()+" "+m.getCustomerName()+" "+m.getAccountBalance());
	}
	
}
public Account getaccountDetails(String mobileNo)
{
	Account acc=data.get(mobileNo);
	
	/*Map<String,Integer> s=new HashMap<String,Integer>();
	Set<Entry<String,Integer>> set=s.entrySet();
	List<Entry<String, Integer>> list = new ArrayList<Entry<String, Integer>>(set);
	 
	   Collections.sort( list, new Comparator<Map.Entry<String, Integer>>()
       {
           public int compare( Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2 )
           {
               return (  o2.getValue()).compareTo( o1.getValue() );
           }

       } );
       for(Map.Entry<String,Integer > entry:list){
           System.out.println(entry.getKey()+" ==== "+entry.getValue());
       }*/
       return acc;
}
public double getaccountBalance(String mobileNo)
{
	Account acc=data.get(mobileNo);
	double acc1=acc.getAccountBalance();
	return acc1;
}public double getrechargeBalance(String mobileNo,double amount)
{
	Account acc=data.get(mobileNo);
	double acc1=acc.getAccountBalance();
	double acc2=amount+acc1;
	return acc2;
}

}
