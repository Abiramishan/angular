package com.cg.ui;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.Map.Entry;

import com.cg.bean.Account;
import com.cg.data.MobileData;
import com.cg.exception.MobileException;

import validation.Validation;

public class RunMain {
	static Scanner sc;
	static MobileData mobileData;
 public static void main(String[] args) throws MobileException {
	System.out.println("*****Menu*****");
	System.out.println("1. Account Balance Enquiry");
	System.out.println("2. Recharge Amount");
	System.out.println("3. Exit");
	 sc=new Scanner(System.in);
	int input=sc.nextInt();
	switch(input)
	{
	case 1:
		viewBalance();
		
		//System.out.println("1.enter mobile number to get balance");
		//viewAccountBalance();
		viewRechargeBalance();
		break;
	case 2:
		break;
	case 3:
		System.exit(0);
	}
	sc.close();
	}
 public static void viewBalance()
 {
	 System.out.println("1.enter mobile number to get balance");
	 sc=new Scanner(System.in);
	 String mobileNo=sc.next();
	 Account acc=getAccountDetails(mobileNo);
	 System.out.println(acc);
			 
	 
 }
 public static void viewAccountBalance() throws MobileException
 {
	 Validation v=new Validation();
	 System.out.println("1.enter mobile number to get balance");
	  sc=new Scanner(System.in);
	 String mobileNo=sc.next();
	 boolean result=v.validateMobileNo(mobileNo);
	 if(result==true)
	 {
		 System.out.println("continue data");
	 }
	 else
	 {
		 throw new MobileException(mobileNo);
	 }
	 double acc=getAccountBalance(mobileNo);
	 System.out.println("balance in the account");
	 System.out.println(acc);
 }
 public static void viewRechargeBalance() throws MobileException
 {
	 Validation v=new Validation();
	 System.out.println("1.enter mobile number to get balance");
	  sc=new Scanner(System.in);
	 String mobileNo=sc.next();
	 boolean result=v.validateMobileNo(mobileNo);
	 if(result==true)
	 {
		 System.out.println("continue data");
	 }
	 else
	 {
		 throw new MobileException(mobileNo);
	 }
	 System.out.println("enter the recharge amount");
	 double acc3=sc.nextDouble();
	 double acc=getRechargeBalance(mobileNo,acc3);
	 System.out.println("balance in the account");
	 System.out.println(acc);
 }
 public static Account getAccountDetails(String mobileNo)
 {
	 Account acc;
	 mobileData=new MobileData();
	 acc=mobileData.getaccountDetails(mobileNo);
	return acc;
	 
 }
 public static double getAccountBalance(String mobileNo)
 {
	 double acc;
	 mobileData=new MobileData();
	 acc=mobileData.getaccountBalance(mobileNo);
	 return acc;
 }
 public static double getRechargeBalance(String mobileNo,double amount)
 {
	 double acc;
	 mobileData=new MobileData();
	 acc=mobileData.getrechargeBalance(mobileNo,amount);
	 return acc;
 }
}
