package com.cg.eis.exception;

public class EmployeeException extends Exception{

	public EmployeeException(String salary) {
		super(salary);
		// TODO Auto-generated constructor stub
		System.out.println("Salary should not be less than 3000");
	}
	

}
