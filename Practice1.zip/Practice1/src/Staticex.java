
public class Staticex 
	{
	static int v=0;
	Staticex()
	{
		v++;
		System.out.println("count" +v);
	
	}
	public static void main(String[] args) {
		new Staticex();
		new Staticex();
		new Staticex();
	}
	
}
