
public class EnumMonths {

	public static void main(String[] args) {
		System.out.println("days in the month of novmber are:" +Months.Nov.getDays());
		System.out.println("day in the month of jan are:" +Months.Jan.getDays());
	}
}
