
public class LoopTask implements Runnable {

	private String loopTaskName;
	public LoopTask(String loopTaskName)
	{
		super();
		this.loopTaskName=loopTaskName;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Starting : "+loopTaskName);
		for(int i=1;i<=2;i++)
		{
			System.out.println("Executing "+loopTaskName+"with"+Thread.currentThread().getName());
		}
		System.out.println("ending "+loopTaskName);
		
	}

}
