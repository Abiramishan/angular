
public class Trainee1 {
	public static void main(String[] args) {
		
		//String name[]=new String[4];
		//int empid[]= {1,23,3,2};
		//int empid[]=new int[4];
		//empid[0]=1245;
		//empid[1]=2345;
		//empid[2]=2456;
		//empid[3]=8769;
				/*name[0]="abi";
				name[1]="shama";
				name[2]="sri";
				name[3]="sriee";*/
				/*for(int i=0;i<name.length;i++)
				{
					System.out.println(name[i]);
				}*/
		trainee[]
		for(int i=0;i<trainee.length;i++)
		{
		//System.out.println(empid[i]);
		Trainee trainee[]=new Trainee[4];
				System.out.println(trainee[]);
		
		}
				
				
	}

}
