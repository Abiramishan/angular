import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class FormattingDate {
public static void main(String[] args) {
	LocalDate currentdate=LocalDate.now();
	DateTimeFormatter formatter1=DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL);
	DateTimeFormatter formatter2=DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG);
	DateTimeFormatter formatter3=DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM);
	DateTimeFormatter formatter4=DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT);
	System.out.println(currentdate.format(formatter2));
	System.out.println(currentdate.format(formatter1));
	System.out.println(currentdate.format(formatter3));
	LocalDate end=LocalDate.now();
	LocalDate v=LocalDate.of(1999,Month.JANUARY,15);
	Period period=v.until(end);
	System.out.println("days:"+period.getDays());
	System.out.println("months:"+period.getMonths());
	System.out.println("year:"+period.getYears());
	}
	}


