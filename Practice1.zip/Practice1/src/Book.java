
public class Book extends Witem {
public Book() {
	System.out.println("dc");
}
}
