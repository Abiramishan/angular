
public class Mediaitem extends Item{
	public Mediaitem()
	{
		System.out.println("Dc");
	}

}
