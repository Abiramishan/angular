
public class Prg1Inter {

}
