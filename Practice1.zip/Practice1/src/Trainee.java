
public class Trainee
{
	int a=5;
	int b=3;
	int result;
public void add()
	{
		//result=a+b;
		//System.out.println("added value is:"+result);
	}
public void mul() 
	{
		result=a*b;
		System.out.println("multi value is :"+result);
	}
}
