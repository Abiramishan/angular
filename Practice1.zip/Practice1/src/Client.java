
public class Client {
public static void main(String[] args) {
	Display display=new Display();
	MyThreadEx mythreadEx1=new MyThreadEx(display,"Dhoni");
	MyThreadEx mythreadEx2=new MyThreadEx(display,"kohli");
	mythreadEx1.start();
	mythreadEx2.start();
}
}
