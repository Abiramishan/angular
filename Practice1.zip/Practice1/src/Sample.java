import java.util.Date;

public class Sample extends Object{
	
	
void task()
{
	
}
public static void main(String[] args) {
	Sample n=new Sample();
	Date date=new Date();
	
	try
	{
	int a[]=new int[2];
a[0]=11;
a[1]=12;
a[2]=1;
//int b=3/0;
//throw new ArithmeticException();
//String str=null;
//System.out.println();
	}
	/*catch(ArithmeticException e)
	{
		//System.out.println(e.getMessage());
		e.printStackTrace();
	}*/
	catch(Exception e)
	{
		System.out.println(e.getMessage());
		e.printStackTrace();
	}
}
}
