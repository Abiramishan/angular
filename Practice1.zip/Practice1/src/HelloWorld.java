import cons.Car;

public class HelloWorld {
 
	public static void main(String[] args) {
		//Trainee n=new Trainee();
		//n.add();
		//n.mul();
		//System.out.println("hellow world");
		//Login n=new Login();
		//n.setPassword("abirami123");
		//System.out.println(n.getPassword());
		//n.setUsername("abishama");
		//System.out.println(n.getUsername());
		//Car car=new Car();
		//car.mtd();
		//Car car2=new Car(4,"swift");
	}
}
 