import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class ArrayListDemo {
public static void main(String[] args) {
	/*ArrayList<String>arrayList=new ArrayList<>();
	arrayList.add("pen");
	arrayList.add("color");
	arrayList.add("marker");
	arrayList.add("eraser");
	System.out.println(arrayList);
	System.out.println("using loop");
	
	for(int i=0;i<arrayList.size();i++)
	{
		System.out.println(arrayList.get(i));
	}
	LinkedList linkedList=new LinkedList();
	linkedList.add("pen");
	linkedList.add("marker");
	linkedList.add("eraser");
	System.out.println(linkedList);
	for(int i=0;i<linkedList.size();i++)
	{
		System.out.println(linkedList.get(i));
	}
	LinkedHashSet hashset=new LinkedHashSet();
	hashset.add("pen");
	hashset.add("color");
	hashset.add("marker");
	System.out.println(hashset);
	//for(int i=0;i<linkedList.size();i++)
	//{
	//	System.out.println(hashset.);
	//}
	HashSet h=new HashSet();
	h.add("pen");
	h.add("color");
	h.add("marker");
	h.add("eraser");
	System.out.println(h);*/
	ArrayList<String>arrayList=new ArrayList<>();
	arrayList.add("pen");
	arrayList.add("color");
	arrayList.add("marker");
	arrayList.add("eraser");
	System.out.println(arrayList);
	System.out.println("using loop");
	for(String data:arrayList)
	{
		System.out.println("data");
	}
	Iterator iterator=arrayList.iterator();
	while(iterator.hasNext())
	{
		System.out.println(iterator.next());
	}
	ListIterator listIterator=arrayList.listIterator();
	
}
}
