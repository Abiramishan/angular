
public class Lab1Exp4 
{
	 boolean f=true;
	public boolean checkNumber(int n)
	{
		int p=0;
		if(n==0)
		{
			System.out.println("");
		}
		for(int i=1;i<n;i++)
		{
			p=i*2;
			if(p==n)
			{
				f=true;
			}
		}
		if(f==true)
		{
			System.out.println("the give number id power of two");
		}
		else
		{
			System.out.println("the number is not power by two");
		}
	return f;
	}
	public static void main(String[] args) {
		Lab1Exp4 v=new Lab1Exp4();
		v.checkNumber(27);
	}
}
