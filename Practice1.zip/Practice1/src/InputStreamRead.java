
public class InputStreamRead {

}
