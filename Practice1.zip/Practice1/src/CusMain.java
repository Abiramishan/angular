import java.util.Scanner;

public class CusMain 
{
public static void main(String[] args) 
{
	//Customer cus = new Customer(String);
	ValidateCus vc=new ValidateCus();
	Scanner s=new Scanner(System.in);
	System.out.println("enter value  :");
	int choice=0;
		choice=	s.nextInt();
	switch(choice)
	{
	case 1:
		System.out.println("enter the customer name ");
		String c1=s.next(); 
		//
		boolean result=vc.validateCusname(c1);
	if(result==true)
	{
		//cus.setName(c1);
		System.out.println("continue");
	}
	else
	{
		System.out.println("customername is not following pattern");
		System.exit(0);
	}
	System.out.println("enter the customer id ");
	String id=s.next();
	//
	boolean result1=vc.validateCusid(id);
	if(result1==true)
	{
		//cus.setId(id);
		System.out.println("continue");
	}
	else
	{
		System.out.println("customername is not following pattern");
		System.exit(0);
	}
	System.out.println("enter the mobile");
	String mb=s.next();
	boolean result2=vc.validateCusmobile(mb);
	if(result2==true)
	{
		System.out.println("continue");
	}
	else
	{
		System.out.println("customermobile number is not following pattern  ");
	}
	
	break;
	case 2:
	{
		System.out.println("enter the mobile");
		String mi=s.next();
		boolean result3=vc.validateCusmailid(mi);
		if(result3==true)
		{
			System.out.println("continue");
		}
		else
		{
			System.out.println("customermailid number is not following pattern  ");
		}
			System.exit(0);
	}
	} 
	s.close();
	}

	
	
}

