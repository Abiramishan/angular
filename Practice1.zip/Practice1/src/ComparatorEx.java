import java.util.Comparator;

public class ComparatorEx implements Comparator{

	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		TraineeDemo t1=(TraineeDemo)o1;
		TraineeDemo t2=(TraineeDemo)o2;
		return t1.name.compareTo(t2.name);
	}
	

}
