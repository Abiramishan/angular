
public class Calculation {

	
 int calculateSum(int n)
{


for(int x=0;x<=15;x++)
{
	int sum=
	return sum;
}

}
}
