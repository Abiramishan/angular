import java.util.Scanner;

public class Lab5Exp3Main {
public static void main(String[] args) {
	int n;
	System.out.println("enter the value of n:");
	Scanner sc=new Scanner(System.in);
	n=sc.nextInt();
int i;
Lab5Exp3 md=new Lab5Exp3();
for(i=2;i<=n;i++)
{
	boolean t=md.findPrime((i));
	if(t==true)
	{
		System.out.println(i);
	}
}
}
}
