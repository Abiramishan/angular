
public class InterThreadDemo {
	int amount=10000;
	public synchronized void withDraw(int amount)
	{
		System.out.println("Going to withdraw money");
		if(this.amount<amount)
		{
			System.out.println("neead to Deposit more money to withdraw");
		}
		try {
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.amount-=amount;
		System.out.println("withdraw successful");
	}
	public synchronized void deposit(int amount) {
		System.out.println("going to Deposit");
		this.amount+=amount;
		System.out.println("Deposited successful");
		notify();
	}
}
