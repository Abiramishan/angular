import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileWrite {
public static void main(String[] args) throws IOException {
	try
	{
		String str="my name is abi";
		FileOutputStream fos=new FileOutputStream("java.txt");
		fos.write(str.getBytes());
		fos.close();
		System.out.println("successfully");
	}
	catch(Exception e)
	{
		System.out.println("exc occured");
	}
	FileInputStream fis=null;
	try 
	{
		fis=new FileInputStream("java.txt");
		int i=0;
		while((i= fis.read())!=-1)
		{
			System.out.println((char)i);
		}
	}
	catch(Exception e)
	{
		System.out.println("exc occured");
		
	}
	finally
	{
		fis.close();
	}
	
}
}