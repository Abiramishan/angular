import java.util.Scanner;

public class prg1Constractor {

	String name ;
	int id ,a ,b,c;
	
	prg1Constractor()
	{
		this(2,"abi");
	}
	prg1Constractor(int id, String name)
	{
		
		System.out.println("ghgklj "+id);
		System.out.println("DSFdsF"+name);
		
	}
	void dispaly()
	{
		Scanner sc= new Scanner(System.in);
		int f=sc.nextInt();
		
		System.out.println("enter the value="+f);
		int g=sc.nextInt();
		System.out.println(g);
		c=a+b;
	}
	public static void main(String[] args) {
		prg1Constractor c=new prg1Constractor();
		//prg1Constractor c1=new prg1Constractor(2,"abi");
		
		
		c.dispaly();
	}
}
