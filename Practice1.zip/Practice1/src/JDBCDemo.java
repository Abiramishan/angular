import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class JDBCDemo {
public static void main(String[] args) {
	try
	{
	Class.forName("oracle.jdbc.driver.OracleDriver");
	//Driver d=new oracle.driver.OracalDeriver();
	//DriverManager.registerDriver(d);
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","India123");
	con.setAutoCommit(false);
	Statement stmt=con.createStatement();
	stmt.execute("select *from emp4");
	
	ResultSet rs=stmt.executeQuery("Select *from emp4");
	while(rs.next())
	{
		int id=rs.getInt(1);
		String name=rs.getString(2);
		System.out.println(id+" "+name);
		
	}
	PreparedStatement st=con.prepareStatement("insert into emp4 values(?,?)");
	st.setInt(1, 107);
	st.setString(2, "priyaaa");
	st.execute("select * from emp4");
	
	//st.execute("insert into emp4 values(4,'bava')");
	//int updateRow = st.executeUpdate("insert into emp4 values(4,'bava')");
	ResultSet r=st.executeQuery();
	while(r.next())
	{
		int id=r.getInt(1);
		String name=r.getString(2);
		System.out.println(id+" "+name);
	}
	con.commit();
	}
	
	catch(Exception e)
	{
		System.out.println(e);
	}
}}

