
public class Lab3Exp1 {
	
public int getSecondSmallest(int[] a)
{
	
	for(int i=0;i<a.length;i++)
	{
		for(int j=i+1;j<a.length;j++)
		{
			if(a[i]>a[j])
			{
				int tmp=a[i];
				a[i]=a[j];
				a[j]=tmp;
			}
		}
	}
	return a[1];
}
public static void main(String[] args) {
	int a[]= {3,4,5,2,1};
	Lab3Exp1 v=new Lab3Exp1();
	int g=v.getSecondSmallest(a);
	System.out.println(g);
}
}
