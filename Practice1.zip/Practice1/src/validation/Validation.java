package validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validation {
	public  boolean validateMobileNo(String cusmobile)
	{
		Pattern pat=Pattern.compile("[0-9]{10}");
		Matcher choi=pat.matcher(cusmobile);
		if(choi.matches())
		{
			return true;
		}
		return false; 
	}
}
