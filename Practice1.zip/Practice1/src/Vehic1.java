
public interface Vehic1 extends Vehic {

	//void ful();
	default void sub()
	{
		System.out.println("123");
	}
}
