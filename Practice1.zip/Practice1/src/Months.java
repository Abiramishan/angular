
public enum Months {
	Jan(31),Feb(28),Mar(31),Jun(30),Aug(31),Sep(30),Nov(30),Dec(31);
	int days;

	public int getDays() {
		return days;
	}

	public void setDays(int days) {
		this.days = days;
	}

	private Months(int days) {
		this.days = days;
	}
	
}
