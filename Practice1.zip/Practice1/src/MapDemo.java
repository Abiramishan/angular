import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;

public class MapDemo {
	public static void main(String[] args) {
		HashMap<Integer,String> hm=new HashMap<Integer, String>();
		hm.put(1234, "abi");
		hm.put(1235,"shama");
		hm.put(1234, "sai");
		System.out.println(hm);
		Set s=hm.keySet();
		System.out.println(s);
		Collection c=hm.values();
		System.out.println(c);
		System.out.println(hm.entrySet());
		Iterator iteration=s.iterator();
		while(iteration.hasNext())
		{
			System.out.println(iteration.next());
		}
		Iterator i=c.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		Vector v=new Vector();
		v.add(2);
		v.add(3);
		v.add(4);
		v.add(5);
		System.out.println(v.contains(3));
		System.out.println(v);
	}

}
