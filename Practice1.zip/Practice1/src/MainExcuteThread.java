import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainExcuteThread {
public static void main(String[] args) {
	ExecutorService es=Executors.newSingleThreadExecutor();
	for (int i=1;i<=1;i++)
	{
		LoopTask looptask=new LoopTask("Looptask "+i);
		es.execute(looptask);
		
	}
	es.shutdown();
}
}
