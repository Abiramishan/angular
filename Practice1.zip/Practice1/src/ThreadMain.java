
public class ThreadMain implements Runnable {
/*public static void main(String[] args) {
	MyThread m=new MyThread();
	m.start();
}*/
	public void run()
	 {
		 for(int i=0;i<=5;i++)
		 {
			 try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 System.out.println(i);
		 }
}
	public static void main(String[] args) {
		ThreadMain mt=new ThreadMain();
		Thread t=new Thread(mt);
		t.start();
	}
}
