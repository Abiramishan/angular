import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
public class LocalDateDemo
{
public static void main(String agrs[])
{
	LocalDate id=LocalDate.now();
	//ZoneDateTime objt=ZonedDateTime.of(LocalDateTime.now(),ZoneId.of("Asia/Kolkata") );
	LocalDate Date=LocalDate.now(ZoneId.of("Asia/Kolkata"));
	LocalDate v=LocalDate.of(1999,Month.JANUARY,15);
	//System.out.println(id);
	Date date=new Date();
	//System.out.println(date);
	//System.out.println(v);
	System.out.println("today:"+Date);
	//System.out.println("tomorrow:"+currentDate.plusDays(1));
	//System.out.println("last month:"+currentDate.minusMonths(1));
	//System.out.println("is Laep?:"+currentDate.isLeapYear());
}
}
