
public class Start {
	
 public static void main(String[] args) {
	

 {
	 
	 String name="abirami";
	 if(name == "abirami")
	 {
		 System.out.println("equal");
	 }
	 else
	 {
		 System.out.println("not equal");
	 }
	 switch(name)
	 {
	 case "sri":
		 System.out.println("name is sri");
	 case "abi":
		 System.out.println("name is abi");
		 default:
			 System.out.println("abishama");
	 }
 }
 }
}
