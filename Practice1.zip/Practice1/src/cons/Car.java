package cons;
public class Car {

	public  Car()
	{
		System.out.println("this is user defined");
	}
	public Car(int capacity,String model) {
	
		 System.out.println("parameterized contructor:"+capacity);
	 }
	 
		public void mtd()
		{
			System.out.println("user defined method");
		}
	
}
