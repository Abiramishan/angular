package cons;

public interface serializable {

}
