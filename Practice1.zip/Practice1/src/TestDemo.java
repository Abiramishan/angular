
public class TestDemo {
void md()
{
	int a;
	System.out.println(a);
}
public static void main(String[] args) {
	TestDemo m=new TestDemo();
	m.md();
}
}
