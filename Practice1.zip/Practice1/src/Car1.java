
public abstract class Car1 {
	 abstract void speed();
	 abstract void capacity();
	 void tran()
	 {
		 System.out.println("transport");
	 }
	public Car1() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("sub const");
	}
	 

}
