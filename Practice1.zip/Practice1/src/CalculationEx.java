
public class CalculationEx {
public int add(int num1,int num2 )
{
	return num1+num2;
	
}
public int multi(int num3,int num4)
{
	return num4*num3;
	
}
public float div(int num1,int num2)
{
	
	return num2/num1;
	
}
boolean
}
