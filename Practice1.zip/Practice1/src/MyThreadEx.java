
public class MyThreadEx extends Thread{
private Display display;
private String name;
public MyThreadEx(Display display,String name)
{
	super();
	this.display=display;
	this.name=name;
}
public void run()
{
	display.wish(name);
}
}
