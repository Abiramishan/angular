import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Lab5Exp4 {
String name;

public boolean validName(String name)
{
	Pattern pattern=Pattern.compile("[A-z]{1}[a-z]{2,10}");
	Matcher matcher=pattern.matcher(name);
	
	if(matcher.matches())
	{
		return true;
	}
	return false;
	
}


}
