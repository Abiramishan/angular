import java.util.function.Supplier;

public class ConstructorReference {

	public static void main(String[] args) {
		Supplier<ItemEx> s1=ItemEx::new;
		System.out.println(s1.get().getName());
		System.out.println(s1.get().getPrice());
	}
}
