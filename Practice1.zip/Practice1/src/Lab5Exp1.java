import java.util.Scanner;

public class Lab5Exp1 {
public static void main(String[] args) {
	Scanner s=new Scanner(System.in);
	System.out.println("1.red \n 2.green \n 3.yellow \n choose the color ");
	switch (s.nextInt())
	{
	case 1:
		System.out.println("Stop");
		break;
	case 2:
		System.out.println("ready");
		break;
	case 3:
		System.out.println(" go");
	break;
}
s.close();
}
}
