
public class Childex {
	public static void main(String[] args) {
		Child n =new Child();
		n.mtd();
		//n.validate();
		System.out.println(n.a);
		System.out.println(n.b);
		
	}
}
