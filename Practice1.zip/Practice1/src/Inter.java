
public interface Inter {
	public void sup();
	public void 

}
