
public class ParamPassingDemo {
/*public static void changeColor(Apple apple)
{
	apple=new Apple();
	apple.color="red";
	System.out.println(apple.color);
	System.out.println(apple.hashCode());
	}*/
public static void main(String[] args) {
	/*Apple apple=new Apple();
	System.out.println(apple.hashCode());

	System.out.println("color:"+apple.color);
	changeColor(apple);
	System.out.println("color:"+apple.color);*/
	Integer a=10;
	Integer b=new Integer(10);
	Integer c= Integer.valueOf("abi");
	Float d=12.45f;
	Float e=new Float(12.12f);
	Float f=Float.valueOf(23.32f);
	
}
}
