
public class TestUde {
public static void validate(int age)throws InvalidAgeException
{
	if(age<18)
	{
		throw new InvalidAgeException("not valid age"+age);
	}
	else
	{
		System.out.println("welcome for voting");
	}
} 
public static void main(String[] args) {
	String age=args[0];
	try
	{
		int ag=Integer.parseInt(age);
		validate(ag);
		catch(InvalidAgeException e)
		{
			System.out.println("exc occured");
		}
		System.out.println("continue with some logis");
	}
}
}
