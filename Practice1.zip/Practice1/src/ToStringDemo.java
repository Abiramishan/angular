

public class ToStringDemo {
public static void main(String[] args) {
	Box box=new Box(10,12,14);
	System.out.println(box);
}
}
