
public class Demoex {
	public static void main(String[] args) {
		System.out.println("a");
	}
	System.out.println("b");
}
