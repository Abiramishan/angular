
public class InterThreadMain 
{
	public static void main(String[] args) {
		
	
    InterThreadDemo demo=new InterThreadDemo();
	new Thread()
	{ 
		public void run()
		{
		demo.withDraw(12000);
		}
	}.start();
	new Thread()
	{
		public void run()
		{
			demo.deposit(10000);
		}
	}.start();
}
}