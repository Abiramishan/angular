import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Excep {
public boolean Exname(String name)
{
	Pattern p=Pattern.compile("[A-Z]{1}[a-z]{2,10}");
	Matcher m=p.matcher(name);
	if(m.matches())
	{
		
		return true;
	}
	
	return false;
}
public boolean Exid(String id)
{
	Pattern p=Pattern.compile("[0-9]{7}");
	Matcher m=p.matcher(id);
	if(m.matches())
	{
		System.out.println("true");
		return true;
	}
	System.out.println("false");
	return false;
}
}
