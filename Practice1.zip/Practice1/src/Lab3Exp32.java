import java.util.Scanner;

public class Lab3Exp32 {
	public static void main(String[] args)
	{
		Lab3Exp32 v=new Lab3Exp32();
		v.mtd1();
	}
void mtd1()
{
	int i,j,z;
	String temp;
	Scanner x=new Scanner(System.in);
	System.out.println("enter size of string");
	int a=x.nextInt();
	z=a/2;
	String[] str=new String[a];
	Scanner y=new Scanner(System.in);
	System.out.println("enter string");
	for(i=0;i<a;i++)
	{
		str[i]=y.nextLine();
		for(i=0;i<a;i++)
		{
		for(j=i+1;j<a;j++)
		{
			if(str[i].compareTo(str[j])>0)
			{
				temp=str[i];
				str[i]=str[j];
				str[j]=temp;
			}
		}
		}
	}
	System.out.println("after arranging");
	if(a%2==0)
	{
		for(i=0;i<a;i++)
		{
			if(i<z)
				System.out.println((str[i].toUpperCase())+"\t");
			else
				System.out.println(str[i]+"\t");
		}
	}
	else if(a%2!=0)
		for(i=0;i<a;i++)
		{
			if(i<=z)
				System.out.println((str[i].toUpperCase())+"\t");
			else
				System.out.println(str[i]+"\t");
			
		}
	
	}
}
