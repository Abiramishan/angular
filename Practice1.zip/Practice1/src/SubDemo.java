
public class SubDemo {
public static void main(String[] args) {
	Demo obj=new Demo();
	System.out.println(obj instanceof Demo);
}
}
