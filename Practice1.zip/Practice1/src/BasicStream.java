import java.util.List;
import java.util.Optional;
import java.util.Arrays;
import java.util.stream.Stream;

public class BasicStream {
public static void main(String[] args) {
	Stream<String> stream=Stream.of("c","a","b","v","g","j");
	stream.forEach((location)-> 
	System.out.println(location));
	List<String> location=Arrays.asList(new String[] {"chennai","mumbai","pune","delhi"});
	stream=location.stream();
	stream.forEach(System.out::println);
	//List<String> cities=new ArraysList<>();
	location.stream().map(String::length).forEach(System.out::println);
	List<Integer> listInt=Arrays.asList(99,88,77,55);
	listInt.stream().filter(num->num>10).forEach(num->System.out.println(num));
	listInt.stream().filter(num->num>10).forEach(System.out::println);
	listInt.stream().limit(4).forEach(System.out::println);
	Optional<Integer> result=listInt.stream().reduce((a,b)->a+b);
	if(result.isPresent())
	{
		System.out.println("Result:"+result.get());
	}
}
}
