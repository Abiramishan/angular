
public interface Vehic {

	void flue();
	void speed();
	
}
