import java.util.Scanner;

public class Lab5Exp5Main {
	public static void validate(int age)throws InvalidAgeException
	{
		if(age<15)
		{
			throw new InvalidAgeException("continue the steps");
		}
		else
		{
			System.out.println("not valid age"+age);
		}
	} 
	public static void main(String[] args) {
		String age;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the age");
		age=sc.next();
		try
		{
			int ag=Integer.parseInt(age);
			validate(ag);
		}
			catch(InvalidAgeException e)
			{
				System.out.println("exc occured");
			}
			sc.close();
		
	}
}
