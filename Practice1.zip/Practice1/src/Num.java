
public class Num {

	public static void main(String[] args) {
		/*for(int i=0;i<=10;i++) {
			System.out.println(i+"number will be display");
	}
		int numA=5;
		int numB=10;
		int numC=0;
		numC= --numA + numB--;
		System.out.println(numA);
		//System.out.println(numB);
		System.out.println(numC);
		int v=1;
		System.out.println(v==1?"A":"B");
		v++;
		System.out.println(v==1?"A":"B");*/
		BoxDemo n=new BoxDemo();
		
		n.setDepth(2.2);
		n.setHeight(3.3);
		n.setWidth(5.5);
		System.out.println(n.getDepth());
		
		System.out.println(n.getHeight());
		System.out.println(n.getWidth());
		n.calcVolume();
}
}
