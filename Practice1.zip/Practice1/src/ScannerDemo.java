import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.InputStreamRead;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class ScannerDemo

{	
	public static boolean validateEmpname(String empname)
	{
		Pattern pattern=Pattern.compile("^[A-z]{1}[a-z]{2-7}");
		Matcher choiceMatch=pattern.matcher(empname);
		if(choiceMatch.matches())
		{
			return true;
		}
		return false; 
	}
public static void main(String[] args) {
	
	/*Scanner scanner=new Scanner("1,2,3,4").useDelimiter(",");
	while(scanner.hasNextInt())
	{*/
	
	Scanner scanner=new Scanner(System.in) ;
	
	//int choice=scanner.nextInt();
	System.out.println("enter emp id");
	String empname=scanner.next();
	
	//System.out.println("after validation");
//	System.out.println(choice);
	
	
		/*int num=scanner.nextInt();
		System.out.println("enter the value");
		int empid=scanner.nextInt();
		System.out.println("enter the name");
		String name=scanner.nextLine();
		
			System.out.println(num);
			System.out.println(empid);
			System.out.println(name);
	
	
	
scanner.close();	*/
	/*
	InputStreamRead ir=new InputStreamRead(System.in);
	BuffereadReader br=new BuffereadReader(ir);
	do
	{
		System.out.println("enter 0to Quit");
		String str=br.readLine();
		i=Interger.parseInt(str);
		if(i==0)
		{
			System.exit(0);
		}
		System.out.println(str);
		while(i!=0);
	}
*/
	
	/*
	System.out.println("enter the value");
	Scanner scanner=new Scanner(System.in) ;
	String str=scanner.nextLine();
	System.out.println(str);
	scanner.close();
	
	int choice=0;
	System.out.println("select the menu");
	System.out.println("select the choice 1");
	System.out.println(" select the choice 2 ");
	System.out.println(" select the choice 3 ");
	choice=scanner.nextInt();
	switch(choice)
	{
	case 1:
		System.out.println("enter the mobile details");
		System.out.println();
		break;
	case 2:
		System.out.println("enter the mobile model");
		break;
	case 3:
		System.out.println("enter the code number");
		System.exit(0);
		break;
	default:
		System.out.println("validate the choice");
		break;
	}*/
}
}
