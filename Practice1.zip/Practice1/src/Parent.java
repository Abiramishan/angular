
public class Parent {
 int a=23;
 void validate()
 {
	 System.out.println("defined");
 }
 Parent()
 {
	 System.out.println("super calss");
 }
 
}
