import static org.junit.jupiter.api.Assertions.*;

import org.junit.Ignore;
import org.junit.jupiter.api.Test;

class CalculationExTest {

	CalculationEx cal;
	@Test
	public void testAdd() {
		cal=new CalculationEx();
		assertEquals(9, cal.add(4,5));
	}
	
	@Test
	
	@Ignore
	public void testmulti() {
		cal=new CalculationEx();
		assertEquals(25, cal.multi(5, 5));
	}
	@Test
	public void testdiv() {
		cal=new CalculationEx();
		assertEquals(1, cal.div(5, 5));
	}
	@Test
	public void test() {
		cal=new CalculationEx();
		boolean result=cal.test();
		assertTrue(result);
	}
}
