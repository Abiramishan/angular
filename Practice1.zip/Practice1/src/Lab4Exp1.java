
public class Lab4Exp1 {
	public int sumCube(int n)
	
	{
		int sum=0,dig=0;
		while(n>0)
		{
			dig=n%10;
			sum=sum+(dig*dig*dig);
			n=n/10;
		}
		System.out.println("the cubes is ="+sum);
		return sum;
	}
public static void main(String[] args) {
	Lab4Exp1 v=new Lab4Exp1();
	v.sumCube(2);
	
}
}
