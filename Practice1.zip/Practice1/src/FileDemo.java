
import java.io.File;
import java.io.IOException;
public class FileDemo {
	
	
	public static void main(String[] args) throws IOException {
		String	fname=args[0];
		File f=new File(fname);
		f.createNewFile();
		System.out.println(f.getName());
		System.out.println(f.getParent());
		System.out.println(f.getAbsolutePath());
		System.out.println(f.length());
		System.out.println(f.canRead()?"true":"false");
	}


		
	}


