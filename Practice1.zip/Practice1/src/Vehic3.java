
public interface Vehic3 {
//void add();
default void sub()
{
	System.out.println("sub");
}
/*
static void fact()
{
	System.out.println("fact");
}*/
}
