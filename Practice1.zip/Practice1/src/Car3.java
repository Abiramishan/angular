
public class Car3 implements Vehic1,Vehic3{

/*	@Override
	public void flue() {
		// TODO Auto-generated method stub
		System.out.println("the flue");
	}

	@Override
	 public void speed() {
		// TODO Auto-generated method stub
		System.out.println("the speed");
	}

	@Override
	public void ful() {
		// TODO Auto-generated method stub
		System.out.println("the full");
		
	}


@Override
public void add() {
	// TODO Auto-generated method stub
	System.out.println("the add");*/
//}
@Override
public void sub() {
	// TODO Auto-generated method stub
	Vehic1.super.sub();
	Vehic3.super.sub();
}

public static void main(String[] args) {
	Car3 n=new Car3();
	n.sub();
	//n.add();
	
}

@Override
public void flue() {
	// TODO Auto-generated method stub
	
}

@Override
public void speed() {
	// TODO Auto-generated method stub
	
}
}
