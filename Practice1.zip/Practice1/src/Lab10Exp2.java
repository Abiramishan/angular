import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import org.omg.CORBA.Current;

public class Lab10Exp2 implements Runnable{

	@Override
	public void run() {
		
	
		try
		{
			LocalDateTime current=LocalDateTime.now();
			DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-YYYY HH:mm:ss");
			String formated=current.format(formatter);
			System.out.println(" "+formated);
			Thread.sleep(10000);
			run();
		}
		catch(Exception e)
		{
			
		}
	}

}
