
public class Customer
{
private String id;
private String name;
private int mobile;
private String mailId;

public Customer(String id, String name, int mobile, String mailId) {
	super();
	this.id = id;
	this.name = name;
	this.mobile = mobile;
	this.mailId = mailId;
}
public Customer(String id, String name, int mobile) {
	super();
	this.id = id;
	this.name = name;
	this.mobile = mobile;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}


}
