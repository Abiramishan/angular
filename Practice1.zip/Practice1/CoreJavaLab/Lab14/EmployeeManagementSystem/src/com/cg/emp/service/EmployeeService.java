package com.cg.emp.service;

import java.util.HashMap;
//import java.util.HashSet;
import java.util.List;

import com.cg.emp.enttity.Employee;
import com.cg.emp.exception.EmployeeException;

public interface EmployeeService 
{
 public int addEmployee(Employee ee) throws EmployeeException;
 public HashMap<Integer,Employee> fetchAllEmp();
 public Employee getEmpById(int empId);
 public Employee searchEmpByName(String name);
 //public HashMap<Integer,Employee> searchEmpByName(String name);
 public int deleteEmp(int empId);
 public Employee updateEmp(String newName,int empId, float newSal);
 public boolean validateEmpName(String name) throws EmployeeException;
 public boolean validateEmpId(String eid) throws EmployeeException;
 public List<Employee> sortEmpName();
}
