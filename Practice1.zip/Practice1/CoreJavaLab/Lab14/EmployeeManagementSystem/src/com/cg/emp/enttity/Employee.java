package com.cg.emp.enttity;

import java.time.LocalDate;

public class Employee {

	private String empName;
	private int empId;
	private float empSal;
	private LocalDate empDoj;
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	public LocalDate getEmpDoj() {
		return empDoj;
	}
	public void setEmpDoj(LocalDate empDoj) {
		this.empDoj = empDoj;
	}
	public Employee(String empName, int empId, float empSal, LocalDate empDoj) {
		super();
		this.empName = empName;
		this.empId = empId;
		this.empSal = empSal;
		this.empDoj = empDoj;
	}
	
	
}
