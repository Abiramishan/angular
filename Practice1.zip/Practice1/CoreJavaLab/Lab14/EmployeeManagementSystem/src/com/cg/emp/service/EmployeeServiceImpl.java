package com.cg.emp.service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.emp.dao.EmployeeDAO;
import com.cg.emp.dao.EmployeeDAOImpl;
import com.cg.emp.enttity.Employee;
import com.cg.emp.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeDAO employeeDAO=new EmployeeDAOImpl();

	@Override
	public int addEmployee(Employee ee) throws EmployeeException {
		employeeDAO.addEmployee(ee);
		
		return ee.getEmpId();
	}

	@Override
	public HashMap<Integer,Employee> fetchAllEmp() {
		
		HashMap<Integer,Employee> hs=employeeDAO.fetchAllEmp();
		return hs;
	}

	@Override
	public Employee getEmpById(int empId) {
		Employee e =employeeDAO.getEmpById(empId);
		return e;
	}

	@Override
	public Employee searchEmpByName(String name) {
		employeeDAO.searchEmpByName(name);
		Employee e=employeeDAO.searchEmpByName(name);
		return null;
	}

	
	

	
	
	
	
	
	
	@Override
	public int deleteEmp(int empId) {
		employeeDAO.deleteEmp(empId);
		return empId;
	}

	@Override
	public Employee updateEmp(String newName,int empId, float newSal) {
		Employee e=employeeDAO.updateEmp(newName, empId, newSal);
		return e;
	}

	@Override
	public boolean validateEmpName(String name) throws EmployeeException {
		Pattern p=Pattern.compile("^[A-Z]{1}[a-z]{2,7}");
		Matcher m=p.matcher(name);
		if(m.matches())
		{
			return true;
		}
		return false; 
		
	}

	@Override
	public boolean validateEmpId(String empId) throws EmployeeException {
		Pattern p=Pattern.compile("[0-9]{4}");
		Matcher m=p.matcher(empId);
		if(m.matches())
		{
			return true;
		}
		return false;
	}

	@Override
	public List<Employee> sortEmpName() {
		
		List<Employee> sort=employeeDAO.sortEmpName();
		return sort;
	}

}
