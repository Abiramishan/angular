import java.util.Arrays;

public class Lab9Exp3 {

	public static void sortSquares(int arr[])
	{
		int n=arr.length;
		for(int i=0;i<n;i++)
		arr[i]=arr[i]*arr[i];
		Arrays.sort(arr);
	}
	public static void main(String[] args) {
		int arr[]= {6,3,4,1,5};
		int n=arr.length;
		System.out.println("Before Sorting");
		for(int i=0;i<n;i++)
			System.out.println(arr[i]+" ");
		sortSquares(arr);
		System.out.println(" ");
		System.out.println("after sort");
		for(int i=0;i<n;i++)
		{
			System.out.println(arr[i]+" ");
		}
	}
}
