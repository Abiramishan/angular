import java.util.Scanner;

public class Lab8Exp7Job {
	
	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name");
		String empname=sc.next();
		Lab8Exp7Validate l = new Lab8Exp7Validate();
		boolean result = l.validate(empname);
		if(result==true)
		{
			Lab8Exp7Details d = new Lab8Exp7Details();
			d.empdetails();
			
		}
		else
		{
			throw new Exception();
		}
		sc.close();
	}

}
