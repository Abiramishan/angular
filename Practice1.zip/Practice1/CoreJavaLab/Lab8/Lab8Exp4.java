import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Scanner;

public class Lab8Exp4 {

	public static void main(String[] args) throws IOException

	{

		Scanner input = new Scanner(System.in);

		System.out.println("Enter file name: (Eg:text.txt)");
		String fileName = input.next();
		input.close();
		File file = new File(fileName);

		if (file.exists())

		{

			System.out.println("File Name: " + file.getName());
			System.out.println("File Type: " + Files.probeContentType(file.toPath()));
			System.out.println("File size: " + file.length() + "bytes");
			System.out.println("File can Execute: " + file.canExecute());
			System.out.println("File is Readable: " + file.canRead());
			System.out.println("File is Writable: " + file.canWrite());
			}
else{
		System.out.println("File not found.");
		}	}
}


