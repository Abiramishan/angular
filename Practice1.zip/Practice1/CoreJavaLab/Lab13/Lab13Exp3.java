import java.util.function.BiFunction;

public class Lab13Exp3 {


	public static void main(String[]args)
	{
		BiFunction<String,String,Boolean> TorF = (Un,Pw) ->
		{if(Un.equals("Administrator")&&(Pw.equals("1234")))
		return true;
		else
			return false;
		
	};	
		
		  System.out.println("Value= " +TorF.apply("Administrator","1234" )); 
}}

