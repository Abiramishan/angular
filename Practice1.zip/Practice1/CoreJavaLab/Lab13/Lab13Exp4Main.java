import java.util.function.BiFunction;
import java.util.function.Supplier;

public class Lab13Exp4Main {

	public static void main(String args[]) {
		Supplier<Lba13Exp4> s1 = Lba13Exp4::new;
		System.out.println(s1.get());
		BiFunction<String,Integer,Lba13Exp4> f = Lba13Exp4::new;
		Lba13Exp4 item = f.apply("xyz", 12);
		System.out.println(item);

		}
}
