
public class Lab13Ex1 {

	public static void main(String[] args) {

		Lab13Exp1 s=(int a,int b)->System.out.println((int)Math.pow(a, b));
		s.sqaure(4, 2);
	}
}
