import java.util.Scanner;
import java.util.stream.IntStream;

public class Lab13Exp5 {

	int fact(int n)
	{
		IntStream is =IntStream.range(1, n);
		int str=is.reduce(n, (a,b)->a*b);
		return str;
	}
	public static void main(String[] args) {
		int n;
		Scanner sc=new Scanner (System.in);
		System.out.println("enter the n value");
		n=sc.nextInt();
		int stream;
		Lab13Exp5 f=new Lab13Exp5();
		stream =f.fact(n);
		System.out.println("factorial of the number is "+stream);
		sc.close();
	}
}
