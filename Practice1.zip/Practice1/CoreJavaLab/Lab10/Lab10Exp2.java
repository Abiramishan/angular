import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import org.omg.CORBA.Current;

public class Lab10Exp2 implements Runnable{

	@Override
	public void run() {
		
		// System.out.println("Timer task started at:"+new Date());
	      
	     //   System.out.println("Timer task finished at:"+new Date());
	
	
		try {
			LocalDateTime ld=LocalDateTime.now();
			DateTimeFormatter d=DateTimeFormatter.ofPattern("hh:mm:ss");
			String text =Current.
			Thread.sleep(10000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		Lab10Exp2 tt=new  Lab10Exp2();
		Thread t=new Thread();
		t.start();
		//Timer timer=new Timer(true);
		//timer.scheduleAtFixedRate(tt, 0, 10*1000);
	/*	System.out.println("timer started");
		//timer.cancel();
		 try {
	            Thread.sleep(15000);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	        timer.cancel();
	        System.out.println("TimerTask cancelled");
	       try {
	            Thread.sleep(15000);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }*/
	}

}
