
public class Lab10Exp1Main {

	public static void main(String[]args)
	{
		

	
		Lab10Exp1 obj=new Lab10Exp1();
     Thread t1=new Thread (obj);
     t1.start();
     
}}

