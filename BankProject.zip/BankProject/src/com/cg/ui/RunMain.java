package com.cg.ui;


import java.sql.SQLException;
import java.util.Random;
import java.util.Scanner;

import com.cg.entity.Account;
import com.cg.exception.AccountException;
import com.cg.service.BankService;
import com.cg.service.BankServicelmplt;




public class RunMain {
	static Scanner sc=null;
	static BankService bankservice=null;
public static void main(String[] args) throws AccountException, ClassNotFoundException, SQLException {
	sc=new Scanner(System.in);
	bankservice=new BankServicelmplt();
	int choice=0;
	
	while (true)
	{
	System.out.println("******WELCOME TO XYZ BANK******");
	System.out.println("1.CREATE ACCOUNT \n  2.SHOW BALANCE \n");
	System.out.println("3.DEPOSIT AMOUNT \n  4.WITHDRAW AMOUNT \n");
	System.out.println("5.FUND TRANSFER \n  6.PRINT TRANSACTION \n");
	
	choice =sc.nextInt();
	switch(choice)
	{
	case 1:
	{
		createaccount();
		break;
	}
	case 2:
	{
		getbalance();
		break;
	}
	case 3:
	{
		deposit();
		break;
	}
	case 4:
	{
		withdraw();
		break;
	}
	case 5:
	{
		fundtransfer();
		break;
	}
	case 6:
	{
		
		break;
	}
	}
	
}
}
public static void createaccount() throws AccountException, ClassNotFoundException, SQLException{
	Random rand = new Random(); 
	 
    int accno= rand.nextInt(100000);
  
    System.out.println("ENTER YOUR NAME:");
    String name=sc.next();
    boolean res= bankservice.validateCusName(name);
    try
	{
		if(res==false)
		{
			throw new AccountException(null); 
		}
	
		
    System.out.println("ENTER YOUR MOBILE NUMBER:");
    String mobno=sc.next();
    boolean res1= bankservice.validateMobileNo(mobno);
    try
	{
		if(res1==false)
		{
			throw new AccountException(null); 
		}
    
    System.out.println("ENTER YOUR LOCATION:");
    String branch=sc.next();
    
    System.out.println("ENTER THE INTIAL AMOUNT TO BE DEPOSITED:");
    double balance=sc.nextDouble();
    
    Account bc=new Account(name, mobno, branch, balance);
    bankservice.createaccount(accno, bc);
    System.out.println("CUSTOMER IS CREATED WITH ACCOUNT NUMBER "+accno);
	}catch(AccountException be){
		System.out.println("enter valid mobile number!!!");
		
	}
		
	}catch(AccountException be){
		System.out.println("enter valid name!!!");
		
	}
   
}
public static void getbalance() throws ClassNotFoundException, SQLException{
	System.out.println("ENTER THE ACCOUNT NUMBER:");
    int accno=sc.nextInt();
    Account bc=bankservice.getbalance(accno);
    if(bc==null){
    System.out.println("Acc.No does not exists");
    }
     System.out.println(bc.getBalance());
	
}
public static void deposit() throws ClassNotFoundException, SQLException{
	System.out.println("ENTER THE ACCOUNT NUMBER:");
	int accno=sc.nextInt();
	Account bcc=bankservice.getbalance(accno);
	 if(bcc==null){
		    System.out.println("Acc.No does not exists");
		    }
	double amt1=bcc.getBalance();
	System.out.println("the reamining balance is: "+amt1);	
	System.out.println("ENTER THE AMOUNT TO BE DEPOSIT:");
	double amt=sc.nextDouble();
	double bal=amt+amt1;
	bankservice.deposit(accno, bal);
	System.out.println("the new balance is"+bal);
	
}
public static void withdraw() throws ClassNotFoundException, SQLException{
	System.out.println("ENTER THE ACCOUNT NUMBER:");
	int accno=sc.nextInt();
	Account bcc=bankservice.getbalance(accno);
	 if(bcc==null){
		    System.out.println("Acc.No does not exists");
		    }
	double amt1=bcc.getBalance();
	System.out.println("the reamining balance is: "+amt1);	
	System.out.println("ENTER THE AMOUNT TO BE WITHDRAW:");
	double amt2=sc.nextDouble();
	if(amt2<amt1){
	double bal=amt1-amt2;
	bankservice.withdraw(accno, bal);
	System.out.println("the new balance is"+bal);}
	System.out.println("insufficient balance");
	
}
public static void fundtransfer() throws ClassNotFoundException, SQLException{
	System.out.println("ENTER YOUR ACCOUNT NUMBER:");
	int accno1=sc.nextInt();
	Account bc=bankservice.getbalance(accno1);
	 if(bc==null){
		    System.out.println("Acc.No does not exists");
		    }
	double temp1=bc.getBalance();
	System.out.println("the  balance is: "+temp1);	
	System.out.println("ENTER THE OTHER ACCOUNT NUMBER:");
	int accno2=sc.nextInt();
	Account bc1=bankservice.getbalance(accno2);
	 if(bc1==null){
		    System.out.println("Acc.No does not exists");
		    }
	double temp2=bc1.getBalance();
	System.out.println("the  balance is: "+temp2);	
	System.out.println("Amount to be transferred: ");
	double amt=sc.nextDouble();
	if(amt<temp1){
	double bal1=temp1-amt;
	double bal2=temp2+amt;
	bankservice.withdraw(accno1, bal1);
	bankservice.deposit(accno2, bal2);
	System.out.println("fund transferred successfully");}
	System.out.println("insufficient balance");

	
}

}
