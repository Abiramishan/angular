package com.cg.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.entity.Account;
import com.cg.jdbc.JDBC;

public class BankDAOImplt implements BankDAO{

	@Override
	public void createaccount(Integer a, Account b) throws ClassNotFoundException, SQLException {
		
		Connection con=JDBC.connect();
		Statement stmt =con.createStatement();
		PreparedStatement pst =con.prepareStatement("INSERT INTO Account VALUES(?,?,?,?,?)");
		pst.setInt(1, a);
		pst.setString(2, b.getCustomername());
		pst.setString(3, b.getMobileno());
		pst.setString(4, b.getbranch());
		pst.setDouble(5, b.getBalance());
		pst.executeUpdate();
	}

	@Override
	public Account getbalance(int accno) throws ClassNotFoundException, SQLException {
		Connection con=JDBC.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("select * from Account where accountnumber='"+accno+" ' ");
		while(res.next()){
			int accountnumber=res.getInt(1);
			String customername=res.getString(2);
			String mobilenumber=res.getString(3);
			String branch=res.getString(4);
			double balance=res.getDouble(5);
			Account bc=new Account(customername, mobilenumber, branch, balance);
		return  bc;
	}
		return null;
	}

	@Override
	public Account deposit(int accno ,double bal) throws ClassNotFoundException, SQLException{
		Connection con=JDBC.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("update Account set balance='"+bal+"'where accountnumber='"+accno+"'");
		
		return null;
	}
	

	@Override
	public Account withdraw(int accno,double bal) throws ClassNotFoundException, SQLException {
		Connection con=JDBC.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("update BankCustomer set balance='"+bal+"'where accountnumber='"+accno+"'");
		
		return null;
	}

	
	

	
}
