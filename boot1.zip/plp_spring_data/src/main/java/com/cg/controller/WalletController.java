package com.cg.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.exception.WalletException;
import com.cg.service.IWalletService;

@RequestMapping("/")
@Controller
public class WalletController {
	@Autowired
	Customer customer;
	@Autowired
	IWalletService iWalletService;

	/**
	 * 
	 * My First Page and it will redirect to my bankpage.jsp page
	 */
	@RequestMapping("/")
	public ModelAndView firstPage() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("bankpage");
		return modelAndView;
	}

	/**
	 * it will redirect to my createnew.jsp page
	 */
	@RequestMapping("/createaccount")
	public String create(ModelMap map) {
		map.addAttribute(customer);
		return "createnew";
	}

	/**
	 * it will redirect to my accountdetails.jsp page and account creation
	 * successful
	 */
	@RequestMapping("/create")
	public ModelAndView account(@ModelAttribute Customer customer, BindingResult errors, HttpServletRequest httpServletRequest)
			throws WalletException {
		ModelAndView modelAndView = new ModelAndView();
		HttpSession httpSession = httpServletRequest.getSession();
		customer = iWalletService.createAccount(customer);
		modelAndView.setViewName("accountdetails");
		httpSession.setAttribute("customer", customer);
		modelAndView.addObject("customerId", customer.getCustomerId());
		modelAndView.addObject("status", "Account created Successfully");
		return modelAndView;
	}


	/**
	 * In this method you can login using customerID
	 */
	@RequestMapping("/logindata")
	public ModelAndView loginData(@RequestParam Integer customerId, HttpServletRequest servletRequest) {
		ModelAndView modelAndView = new ModelAndView();
		HttpSession httpSession = servletRequest.getSession();
		try {
			customer = iWalletService.validateId(customerId);
		} catch (Exception e) {
			httpSession.setAttribute("status", "Invalid CustomerId");
			modelAndView.setViewName("exception");
			return modelAndView;
		}
		if (customer != null) {
			httpSession.setAttribute("customer", customer);
			modelAndView.setViewName("accountdetails");

		} else {
			modelAndView.addObject("status", "invalid username/pasword");
			modelAndView.setViewName("bankpage");
		}
		return modelAndView;
	}

	/**
	 * it will redirect to showbalance.jsp page where i can check my balance
	 */
	@RequestMapping("/showbalance")
	public ModelAndView showBalance(HttpServletRequest httpServletRequest, @RequestParam int customerId)
			throws WalletException {
		ModelAndView modelAndView = new ModelAndView();
		HttpSession httpSession = httpServletRequest.getSession();
		double balance = iWalletService.showBalance(customerId);
		httpSession.setAttribute("balance", balance);
		modelAndView.setViewName("showbalance");
		return modelAndView;
	}

	/**
	 * After showBalance you can Directly go to your Home page
	 */
	@RequestMapping("/home")
	public String account() {
		return "accountdetails";
	}

	@RequestMapping("/depositmoney")
	public String showDepositPage(HttpServletRequest httpServletRequest) {
		HttpSession httpSession = httpServletRequest.getSession();
		httpSession.setAttribute("result", "");
		httpSession.setAttribute("amount", "");
		httpSession.setAttribute("status", "");
		return "depositpage";
	}

	@RequestMapping("/deposit")
	public ModelAndView depositAmount(HttpServletRequest httpServletRequest, @RequestParam double amount)
			throws WalletException {
		ModelAndView modelAndView = new ModelAndView();
		HttpSession httpSession = httpServletRequest.getSession();
		customer = (Customer) httpSession.getAttribute("customer");
		boolean result = iWalletService.deposit(customer.getCustomerId(), amount);

		if (result) {
			httpSession.setAttribute("result", "deposited successfully");
			httpSession.setAttribute("amount", amount);
			httpSession.setAttribute("status", "Your deposited amount is ");
			modelAndView.setViewName("depositpage");
		}
		return modelAndView;
	}

	@RequestMapping("/withdrawmoney")
	public String showWithdrawPage(HttpServletRequest httpServletRequest) {
		HttpSession httpSession = httpServletRequest.getSession();
		httpSession.setAttribute("result", "");
		httpSession.setAttribute("amount", "");
		httpSession.setAttribute("status", "");
		return "withdrawpage";
	}

	@RequestMapping("/withdraw")
	public ModelAndView withdrawAmount(HttpServletRequest httpServletRequest, @RequestParam double amount)
			throws WalletException {

		ModelAndView modelAndView = new ModelAndView();
		HttpSession httpSession = httpServletRequest.getSession();
		try {
			customer = (Customer) httpSession.getAttribute("customer");
			Customer c = iWalletService.validateId(customer.getCustomerId());
			boolean result = iWalletService.withdraw(customer.getCustomerId(), amount);

			if (result) {
				httpSession.setAttribute("result", "withdraw successfully");
				httpSession.setAttribute("status", "Your Withdraw amount is ");
				httpSession.setAttribute("amount", amount);
				modelAndView.setViewName("withdrawpage");
			}
		} catch (Exception e) {
			httpSession.setAttribute("status", "Insufficient Amount");
			modelAndView.setViewName("exception");
			return modelAndView;
		}

		return modelAndView;
	}

	@RequestMapping("/fundtransfer")
	public String showFundTrasferPage(HttpServletRequest httpServletRequest) {
		HttpSession httpSession = httpServletRequest.getSession();
		httpSession.setAttribute("result", "");
		httpSession.setAttribute("amount", "");
		httpSession.setAttribute("status", "");
		return "fundtrasferpage";
	}

	@RequestMapping("/transfer")
	public ModelAndView fundtransfer(HttpServletRequest httpServletRequest, @RequestParam double amount,
			@RequestParam int receiverid) throws WalletException {
		ModelAndView modelAndView = new ModelAndView();
		HttpSession httpSession = httpServletRequest.getSession();
		customer = (Customer) httpSession.getAttribute("customer");
		Customer c = null;
		try {
			c = iWalletService.validateId(customer.getCustomerId());
		} catch (Exception e) {
			httpSession.setAttribute("status", "Invalid ReceiverId");
			modelAndView.setViewName("exception");
			return modelAndView;
		}
		boolean result = iWalletService.fundTransfer(customer.getCustomerId(), receiverid, amount);
		if (c.getAccount().getBalance() < amount) {
			try {
				throw new WalletException("Insufficient Balance.....Try again!!!");
			} catch (Exception e) {
				httpSession.setAttribute("status", "Invalid ReceiverId");
				modelAndView.setViewName("exception");
				return modelAndView;
			}
		} else {
			if (result) {
				httpSession.setAttribute("result", "Fundtransferred successfully");
				httpSession.setAttribute("amount", amount);
				httpSession.setAttribute("status", "transferred to customerId");
				httpSession.setAttribute("receiverid", receiverid);
				modelAndView.setViewName("fundtrasferpage");
			}
		}
		return modelAndView;
	}

	@RequestMapping("/printtransactions")
	public ModelAndView viewTransactions(HttpServletRequest httpServletRequest) throws WalletException {
		ModelAndView modelAndView = new ModelAndView();
		HttpSession httpSession = httpServletRequest.getSession();
		customer = (Customer) httpSession.getAttribute("customer");
		List<Transaction> transactionList = iWalletService.printTransaction(customer.getCustomerId());
		modelAndView.addObject("transactionList", transactionList);
		modelAndView.setViewName("printtransaction");
		return modelAndView;
	}

	@RequestMapping("/logout")
	public String logout() {
		return "bankpage";
	}
}