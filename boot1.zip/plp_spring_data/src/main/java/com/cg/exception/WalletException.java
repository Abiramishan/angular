package com.cg.exception;

public class WalletException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	 String message;

	public WalletException() {
	}

	public WalletException(String message) {
			System.out.println(message);
			this.message=message;
	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return this.message;
	}

	

}
