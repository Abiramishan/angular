package runner;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"C:\\Users\\abshanmu\\Documents\\shama\\ValidationDemoTest\\src\\test\\java\\feature\\a.feature"}
		 ,glue= {"C:\\Users\\abshanmu\\Documents\\shama\\ValidationDemoTest\\src\\test\\java\\stepdef\\stepdef.java"}
		  ,plugin= {"pretty","html:target/akbar-report"}
			,monochrome=true
			,dryRun=true
		)
public class r {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
