package stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {

	WebDriver d;

@Given("^Open ksrtc web site$")
public void open_ksrtc_web_site() throws Throwable {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\abshanmu\\Desktop\\chromedriver_win32 (1)\\chromedriver.exe");
	d=new ChromeDriver();
	d.get("https://ksrtc.in");
	d.manage().window().maximize();
  //  throw new PendingException();
}

@When("^user  inputs Username$")
public void user_inputs_Username() throws Throwable {
	//d.findElement(By.xpath("/html/body/header/div/div/div[1]/div/ul[1]/li[1]/a"));
	d.findElement(By.linkText("Sign In")).click();
   d.findElement(By.xpath("//*[@id=\"userName\"]")).sendKeys("mah@yahoo.com");
    //throw new PendingException();
}

@When("^user inouts password$")
public void user_inouts_password() throws Throwable {
	  d.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("mysore15");
 //   throw new PendingException();
}

@Then("^login should be successfull$")
public void login_should_be_successfull() throws Throwable {
	d.findElement(By.xpath("//*[@id=\"submitBtn\"]")).click();
	boolean e=d.getPageSource().contains("Login incorrect. Please try again");
	if(e) 
	{
		System.out.println("Login Failed");
	}
	else
	{
		System.out.println("Login success");
	}
   // throw new PendingException();
}

@Then("^login should be faild$")
public void login_should_be_faild() throws Throwable {
   
   // throw new PendingException();
}
}