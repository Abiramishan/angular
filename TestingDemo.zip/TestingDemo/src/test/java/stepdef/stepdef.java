package stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {
	WebDriver d;
	@Given("^Open bank of america$")
	public void open_bank_of_america() throws Throwable 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\abshanmu\\Desktop\\chromedriver_win32 (1)\\chromedriver.exe");
		d=new ChromeDriver();
		d.get("https://www.bankofamerica.com");
		d.manage().window().maximize();
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
	}

	@When("^i enter valid data in searchbox$")
	public void i_enter_valid_data_in_searchbox() throws Throwable 
	{
		d.findElement(By.xpath("//*[@id=\"nav-search-query\"]")).sendKeys("Savings Account");
		d.findElement(By.xpath("//*[@id=\"searchStub\"]/div/div/form/div[1]/input[2]")).submit();
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}

	@Then("^I should see a module$")
	public void i_should_see_a_module() throws Throwable 
	{
		boolean text=d.getPageSource().contains("Page Not Available");
		if(text)
		{
		System.out.println("on entering savings in search box and clicking search button the module for savings appeared ��-no defect");
		}
		else
		{
		System.out.println("on entering savings in search box and clicking search button the module for savings not appeared �-A defect");
		}
		}
	
	}