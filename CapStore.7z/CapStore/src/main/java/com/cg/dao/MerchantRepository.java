package com.cg.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.cg.entity.Merchant;

@Repository

public interface MerchantRepository extends CrudRepository<Merchant,Integer>{

	

}
