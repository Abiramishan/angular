package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.Id;



@Entity(name="merchantable")
public class Merchant  {


	@Id
	
	private int merchantId;
	
	private String merchantName;
	
	private String password;
	
	private String email;
	
	private String contactNo;
	
	private String location;
	
	private String productCategory;
	
	private String question;
	
	private String answer;
	
	private int rating;
	
	private String feedback;
	
	private int discount;

	public int getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}



	public int getDiscount() {
		return discount;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	@Override
	public String toString() {
		return "Merchant [merchantId=" + merchantId + ", merchantName=" + merchantName + ", password=" + password
				+ ", email=" + email + ", contactNo=" + contactNo + ", location=" + location + ", productCategory="
				+ productCategory + ", question=" + question + ", answer=" + answer + ", rating=" + rating
				+ ", feedback=" + feedback + ", discount=" + discount + "]";
	}

	public Merchant(int merchantId, String merchantName, String password, String email, String contactNo,
			String location, String productCategory, String question, String answer, int rating, String feedback,
			int discount) {
		super();
		this.merchantId = merchantId;
		this.merchantName = merchantName;
		this.password = password;
		this.email = email;
		this.contactNo = contactNo;
		this.location = location;
		this.productCategory = productCategory;
		this.question = question;
		this.answer = answer;
		this.rating = rating;
		this.feedback = feedback;
		this.discount = discount;
	}

	public Merchant() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
}
