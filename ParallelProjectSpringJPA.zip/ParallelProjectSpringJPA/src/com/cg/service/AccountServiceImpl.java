package com.cg.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.AccountDao;
import com.cg.entity.Account;

@Service
@Transactional
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountDao accountDao;
	
	@Override
	public Account createAccount( Account acc) {
		// TODO Auto-generated method stub
		return accountDao.createAccount( acc);
	}

	@Override
	public Account showBalance(int accNo) {
		// TODO Auto-generated method stub
		return accountDao.showBalance(accNo);
	}

	@Override
	public Account deposit(int accNo, double amount) {
		// TODO Auto-generated method stub
		return accountDao.deposit(accNo, amount);
	}

	@Override
	public Account withDraw(int accNo, double amount) {
		// TODO Auto-generated method stub
		return accountDao.withDraw(accNo, amount);
	}

	@Override
	public Account fundTransfer(int accNo, double amount) {
		// TODO Auto-generated method stub
		return accountDao.fundTransfer(accNo, amount);
	}

	@Override
	public Account printTransactions(int accNo) {
		// TODO Auto-generated method stub
		return accountDao.printTransactions(accNo);
	}

}
