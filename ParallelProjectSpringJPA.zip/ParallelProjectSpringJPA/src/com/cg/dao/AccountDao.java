package com.cg.dao;

import com.cg.entity.Account;

public interface AccountDao {
	public Account createAccount(Account acc);
	public Account showBalance(int accNo);
	public Account deposit(int accNo,double amount);
	public Account withDraw(int accNo,double amount);
	public Account fundTransfer(int accNo,double amount);
	public Account printTransactions(int accNo);
}
