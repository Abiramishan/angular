package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.entity.BankCustomer;

@Repository
public class BankDaoImpl implements BankDao{

	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public BankCustomer addAccount(BankCustomer bank) {
		entitymanager.persist(bank);
		entitymanager.flush();
			return bank;
	}

	@Override
	public BankCustomer showBalance(int accountNo) {
		
		return entitymanager.find(BankCustomer.class,accountNo);
	}

	@Override
	public BankCustomer deposit(int accountNo, int amount) {
		BankCustomer bank=entitymanager.find(BankCustomer.class,accountNo);
		int bal=bank.getBalance();
		int updatedAmt=bal+amount;
		bank.setBalance(updatedAmt);
		entitymanager.merge(bank);
		return bank;
	}

	@Override
	public BankCustomer withdraw(int accountNo, int amount) {
		BankCustomer bank=entitymanager.find(BankCustomer.class,accountNo);
		int bal=bank.getBalance();
		if(bal>amount) {
			int updatedAmt=bal-amount;
			bank.setBalance(updatedAmt);
			entitymanager.merge(bank);
		}
		else {
			System.out.println("Insufficient Balance");
		}
		return bank;
	}

	@Override
	public BankCustomer fundTransfer(int accountNo, int accountNo2, int amount) {
		BankCustomer bank=entitymanager.find(BankCustomer.class,accountNo);
		BankCustomer bank1=entitymanager.find(BankCustomer.class,accountNo2);
		int bal1=bank.getBalance();
		int bal2=bank1.getBalance();
		if(bal1>amount) {
			int amount1=bal1-amount;
			int amount2=bal2+amount;
			bank.setBalance(amount1);
			bank1.setBalance(amount2);
			entitymanager.merge(bank);
			entitymanager.merge(bank1);
		}
		else {
			System.out.println("unable to process due to insuffecient funds");
		}
		return bank;
	}

	

}
