package com.cg.service;

import com.cg.entity.BankCustomer;

public interface BankService {


	public BankCustomer addAccount(BankCustomer bank);
	public BankCustomer showBalance(int accountNo);
	public BankCustomer deposit(int accountNo, int amount);
	public BankCustomer withdraw(int accountNo, int amount);
	public BankCustomer fundTransfer(int accountNo, int accountNo2, int amount);
	
}
