package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.BankCustomer;
import com.cg.service.BankService;

@RestController
public class BankController {
	
	@Autowired
	private BankService bankservice;
	
	@RequestMapping(value="/add/{customername}/{branch}/{mobileno}/{balance}", method = RequestMethod.GET,headers="Accept=application/json")
	public String addAccount(@PathVariable String customername,@PathVariable String branch,@PathVariable String mobileno,@PathVariable int balance) 
	{
		
		BankCustomer bank=new BankCustomer();
		bank.setCustomername(customername);
		bank.setBranch(branch);
		bank.setMobileno(mobileno);
		bank.setBalance(balance);
		BankCustomer acc=bankservice.addAccount(bank);
		String res="Account Added Successfully and Account Id is "+acc.getAccountNo();
		return res;
	}

	@RequestMapping(value ="/showBalance/{AccountNo}",method = RequestMethod.GET,headers="Accept=application/json")
	public BankCustomer showBalance(@PathVariable int AccountNo) 
	{
		BankCustomer bank=bankservice.showBalance(AccountNo);
		return bank;
	}

	@RequestMapping(value = "/deposit/{AccountNo}/{Amount}",method = RequestMethod.GET,headers="Accept=application/json")
	public BankCustomer deposit(@PathVariable int AccountNo,@PathVariable int Amount) {
		BankCustomer bank=bankservice.deposit(AccountNo, Amount);
		return bank;
	}
	@RequestMapping(value = "/withDraw/{AccountNo}/{Amount}",method = RequestMethod.GET,headers="Accept=application/json")
	public BankCustomer withdraw(@PathVariable int AccountNo,@PathVariable int Amount) {
		BankCustomer bank=bankservice.withdraw(AccountNo, Amount);
		return bank;
	}
	@RequestMapping(value = "/fundTransfer/{AccountNo}//{AccountNo2}/{Amount}",method = RequestMethod.GET,headers="Accept=application/json")
	public BankCustomer fundtransfer(@PathVariable int AccountNo,@PathVariable int AccountNo2,@PathVariable int Amount) {
		BankCustomer bank=bankservice.fundTransfer(AccountNo, AccountNo2, Amount);
		return bank;
	}

}
