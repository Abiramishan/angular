import { Component, OnInit } from '@angular/core';
import { IMerchant } from '../merchant';
import { ActivatedRoute, Router } from '@angular/router';
import { MerchantService } from '../merchant.service';

@Component({
  selector: 'app-addmerchant',
  templateUrl: './addmerchant.component.html',
  styleUrls: ['./addmerchant.component.css']
})
export class AddmerchantComponent {
  merchants:IMerchant;
  yash:boolean=false;

  constructor(private service :MerchantService) 
  {
    
    this.merchants=new IMerchant();
    
   }

  onSubmit() {
    alert("Admin  Successfully")
   
     this.service.save(this.merchants).subscribe();
  }
  myFunc()
  {
    this.service.getMerchant().subscribe(data=>this.merchants=data);
    this.yash=true;
  }

   
}
