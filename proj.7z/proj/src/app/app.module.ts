import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { Route,RouterModule } from '../../node_modules/@angular/router';
import { AddmerchantComponent } from './addmerchant/addmerchant.component';
import {HttpClientModule} from '@angular/common/http';
import { DeletemerchantComponent } from './deletemerchant/deletemerchant.component';
import { MerchantService } from './merchant.service';


const routes: Route []=[
 
  {
    path:'addmerchant',
    component:AddmerchantComponent
   },
   {
    path:'deletemerchant',
    component:DeletemerchantComponent
   }
   
   ];



@NgModule({
  declarations: [
    AppComponent,
    AddmerchantComponent,
    DeletemerchantComponent,
   
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes),
    HttpClientModule
  ],
  providers: [MerchantService],
  bootstrap: [AppComponent]
})
export class AppModule { }
