import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeletemerchantComponent } from './deletemerchant.component';

describe('DeletemerchantComponent', () => {
  let component: DeletemerchantComponent;
  let fixture: ComponentFixture<DeletemerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeletemerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeletemerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
