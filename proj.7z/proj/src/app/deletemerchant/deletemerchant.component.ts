import { Component, OnInit } from '@angular/core';
import { IMerchant } from '../merchant';
import { MerchantService } from '../merchant.service';

@Component({
  selector: 'app-deletemerchant',
  templateUrl: './deletemerchant.component.html',
  styleUrls: ['./deletemerchant.component.css']
})
export class DeletemerchantComponent implements OnInit {
  
  merchants:IMerchant;
  
  constructor(private service :MerchantService) { }

  ngOnInit() {
 
    this.service.getMerchant().subscribe(data=>this.merchants=data);
  }

   delete(merchantId:number)
    {
      console.log(merchantId);
      this.service.delete(merchantId).subscribe(data=>this.merchants=data);
      
    } 
   
      
  }   
  
 

