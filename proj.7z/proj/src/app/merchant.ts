export class IMerchant
{
    merchantId:number;
    merchantName:string;
    password:string;
    email:string;
    contactNo:string;
    location:string;
    productCategory:string;
    question:string;
    answer:string;
    rating: number;
    feedback:string;
    discount:number;
}