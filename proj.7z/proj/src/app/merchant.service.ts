import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';
import { IMerchant } from './merchant';


@Injectable({
  providedIn: 'root'
})
export class MerchantService {
  private url:string;
  private url1:string;
  private url2:string;

  

  constructor(private http: HttpClient) { 
    this.url='http://localhost:8084/merchants';
    this.url1='http://localhost:8084/add';
    this.url2='http://localhost:8084/delete';
  }

  

  public save(merchants: IMerchant) {
    return this.http.post<IMerchant>(this.url1,merchants);
  }
   getMerchant():Observable<IMerchant>{

    return this.http.get<IMerchant>(this.url);

  } 

   delete(merchantId:number):Observable<any>{

    return this.http.delete(`${this.url2}/${merchantId}`); 

    } 
  
}
